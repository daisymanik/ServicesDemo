#Welcome to Genie 4

To find out more about Genie, visit the [Genie Confluence Page.](https://confluence.global.standardchartered.com/display/GENIE)
