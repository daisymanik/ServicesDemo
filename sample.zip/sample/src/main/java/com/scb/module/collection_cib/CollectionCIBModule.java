package com.scb.module.collection_cib;

import com.standardchartered.genie.GenieRuntime;
import com.standardchartered.genie.module.BaseGenieGlueModule;
import com.standardchartered.genie.exception.GenieException;



import java.util.ArrayList;
import java.util.List;

public class CollectionCIBModule extends BaseGenieGlueModule {
    @Override
    public String getName() {
    	return "collection_cib";
        
    }

    @Override
    public void initialise(GenieRuntime runtime) {
    }

    @Override
    public List<String> getGluePaths() {
        List<String> gluePaths = new ArrayList<>();
        gluePaths.add("classpath:com.scb.module.collection_cib.glue");
        gluePaths.add("classpath:snippet");
        return gluePaths;
    }


}
