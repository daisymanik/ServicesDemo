package com.scb.module.collection_cib_Utility;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;

import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.junit.Assert;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.scb.module.collection_cib.DataBaseConnectivity;
import com.scb.module.collection_cib.StepDef;
import com.standardchartered.genie.model.v1_0.fragment.Scenario;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class SoapXMLParser {
	public Scenario scenario;
	FileInputStream input;
	public Response response;
	public String customerReferenceNumber = "";
	public String EopsresponseAsString = "";
	public String RequestSoapMessageInEOPS_HUB_RB_SIT01 = "";
	public String ResponseSoapMessageInEOPS_HUB_RB_SIT01 = "";
	public String EopsToiBankingNotificationPayload = "";
	public String scenarioIdFromExcel = "";
	public String keyTag = "";
	public String keyTagValue = "";
	public String keyDetailsUpdateinExcel="";
	public String keyValueUpdateinExcel="";
	public String forAllstatusHtml="";
	public Map<String, String> iBankingRequest = new HashMap<String, String>();
	public Map<String, String> eopsresponse = new HashMap<String, String>();
	public Map<String, String> statusmap = new HashMap<String, String>();
	public Map<String,String> RequestSoapMessageInEOPS=new HashMap<String, String>();
	public Map<String, String> ICMtoEopsResponse=new HashMap<String,String>();
	public Map<String,String> EopstoICMPayload=new HashMap<String,String>();
	public Map<String, String> requestDetails = new HashMap<String, String>();
	public Map<String, String> responseDetails = new HashMap<String, String>();
	Logger logger = Logger.getLogger(SoapXMLParser.class);
	Fillo fillo = new Fillo();
	Connection filloconnection;
	CommonFunctions common=new CommonFunctions();
	public void baseUrlDetails() {

		try {
		//	System.out.println(common.readProperties(FileUtilities.inputPropertyDetails, "BaseUrl"));
		//	RestAssured.baseURI=common.readProperties(FileUtilities.inputPropertyDetails, "BaseUrl");
		RestAssured.baseURI = "http://10.23.208.182:8080";
			StepDef.scenario.write("End Point Details");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	//@Daisy: Function to be converted as most dynamic - should be able to change any value
	public void updateThePayloadValues() throws Exception
	{
		
			FileInputStream fisTargetFile = new FileInputStream(FileUtilities.inputXmlPath);
			String iBankingRequestAsString = IOUtils.toString(fisTargetFile, "UTF-8");
			System.out.println("Input--------->" + iBankingRequestAsString);
			fetchallxmlTags(iBankingRequestAsString, iBankingRequest,"iBankingRequestPayload_Key","iBankingRequestPayload_Value");
			//FileReader reader = new FileReader(FileUtilities.inputXmlPath);
			input = new FileInputStream(FileUtilities.inputXmlPath);
			response = RestAssured.given().header("Content-type", "text/xml").and()
					.body(IOUtils.toString(input, "UTF-8")).when().post("/eopsServiceProvider/ProcessService");
			EopsresponseAsString = response.asString();
			System.out.println("Response as String---------->>>>>" + response.asString());
			retrieveCustomerNumber();	

	}

	//@Daisy: Done!
	public void updateResponseValues() throws Exception {
		
		fetchallxmlTags(EopsresponseAsString, eopsresponse,"EopstoiBankingResponsePayload_Key","EopstoiBankingResponsePayload_Value");
	}

	//@Daisy: Done!
	public String verifyContentFromSoapXml(String xmlasString, String tagNametoVerify) throws Exception {

		try {
			List<String> output = getFullNameFromXml(xmlasString, tagNametoVerify);
			String[] strarray = new String[output.size()];
			output.toArray(strarray);
			String tagValue = removeOpenandClosebracket(Arrays.toString(strarray));
			return tagValue;

		} catch (Exception e) {
			return "mentionedtagnotavailable";
		}
	}

	//@Daisy : Done!
	public void verifyResponseCode() throws Exception {
		System.out.println("Response as String"+response.toString());
		//getFullNameFromXml(EopsresponseAsString, "middleName");
		int responseCode = response.getStatusCode();
		if (responseCode == 200) {
			StepDef.scenario.write("Response code Received------->"+responseCode);
			System.out.println("responseCode - " + responseCode);			

		} else {
			StepDef.scenario.write("Response code Received-------->"+responseCode);
			
		}

	}

	//@Daisy : Done!
	public String removeOpenandClosebracket(String inputString) {
		String output = inputString;
		output = output.replace("[", "");
		output = output.replace("]", "");
		return output;

	}

	//@Daisy : Done!
	public Document loadXMLString(String response) throws Exception {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(response));
		return db.parse(is);
	}

	//@Daisy : Check for duplicate function, else retain getfullnamefromxml
	public List<String> getFullNameFromXml(String response, String tagName) throws Exception {
		Document xmlDoc = loadXMLString(response);
		System.out.println("Get Full Name From XML" + xmlDoc.getNodeName().toString());
		NodeList nodeList = xmlDoc.getElementsByTagName(tagName);
		List<String> ids = new ArrayList<String>(nodeList.getLength());
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node x = nodeList.item(i);
			System.out.println("Node Values------>" + x.getNodeName().toString());
			ids.add(x.getFirstChild().getNodeValue());

		}
		return ids;
	}

	//@Daisy : Excel printing can be included in this method
	public Map<String, String> selectValuesFromDB(String customerRefId) throws Exception {
		DataBaseConnectivity dbcon = new DataBaseConnectivity();
		Statement sqlstatement = dbcon.createConnection();
		Thread.sleep(10000);
		String readRecordSQL = "SELECT t.taskid,t.txrefno,t.statuscode,t.stepname,t.steplabel,t.selectedresponse,t.userresponse,t.responsecode,t.stepresponses,t.countrycode,t.processid,t.enqueuetime,t.locktime,t.modifiedtime,t.elapsedtime,t.lockeduser,t.channel,t.modifieduserid,t.queuename,t.scantime,t.isolatedregion,t.CATEGORY,t.laststepname,t.referrallist,t.seckey FROM eops_hub_rb_sit01.task t WHERE t.txrefno="
				+ "'" + customerRefId + "'" + "ORDER BY taskid DESC";
		System.out.println("DB connection Established: " + readRecordSQL);
		ResultSet myResultSet = sqlstatement.executeQuery(readRecordSQL);

		while (myResultSet.next()) {
			String stepName = myResultSet.getString("stepname");
			String stepresponse = myResultSet.getString("selectedresponse");
			System.out.println("stepName" + stepName + "and " + stepresponse);
			statusmap.put(stepName, stepresponse);
		}
		return statusmap;
	}

	
	
	//@Daisy: Assert's should work and still execution should continue
	public String verifyStatusCompleted(String status,String KeyValue) {
		String detailsToUpdate="";
		if (KeyValue.equalsIgnoreCase("Complete")) {
			 detailsToUpdate="<tr>"+"<td>"+status+"</td>"+"<td>"+KeyValue+"</td>"+"<td>Complete</td>"+"<td>Pass</td>"+"</tr>";
			reportlog("StatusNameFromDB", KeyValue, "Complete", "Pass");
			return detailsToUpdate;
		}  else 
		{
			 detailsToUpdate="<tr>"+"<td>"+status+"</td>"+"<td>"+KeyValue+"</td>"+"<td>Complete</td>"+"<td>Fail</td>"+"</tr>";
			reportlog("StatusNameFromDB", KeyValue, "Complete", "Fail");
			return detailsToUpdate;
		}
	}

	//@ulaganathan: newly added function
		public void verifyUP1ReqStatus(String KeyValue) {
			if (KeyValue.equalsIgnoreCase("UP1Req")) {
				reportlog("StatusNameFromDB", KeyValue, "UP1Req", "Pass");
			}  else 
			{
				reportlog("StatusNameFromDB", KeyValue, "UP1Req", "Fail");
			}
		}
		
		
		//@ulaganathan: newly added function
		public void verifySTPReqStatus(String KeyValue) {
			if (KeyValue.equalsIgnoreCase("STPReq")) {
				reportlog("StatusNameFromDB", KeyValue, "STPReq", "Pass");
			}  else 
			{
				reportlog("StatusNameFromDB", KeyValue, "STPReq", "Fail");
			}
		}
		
		
		
		
		
	//@Daisy : on fixing verifyStatusCompleted, commented lines to be enabled
	public void verifyCompleteStatus() throws Exception {
		Map<String, String> verifyStatus;
		String keys = "";
		String keyValues = "";
		try {

			verifyStatus = selectValuesFromDB(customerReferenceNumber);
			int verifysize = verifyStatus.size();

			for (int i = 0; i < 3; i++) {
				Thread.sleep(35000);
				if (verifysize != 10) {
					verifyStatus = selectValuesFromDB(customerReferenceNumber);
				}
			}

			for (Entry<String, String> m : verifyStatus.entrySet()) {

				keys = keys + m.getKey().toString() + "|";
				keyValues = keyValues + m.getValue().toString() + "|";
				String KeyValue = m.getKey().toString();
				String statusValue="";
				String output="";
				switch (KeyValue) {
				case "AR_UP1":
					
					 //statusValue=m.getValue().toString();		 
					output=verifyStatusCompleted(KeyValue,statusValue);
					forAllstatusHtml=forAllstatusHtml+output;
					break;
					
				case "AR_UP2":
					statusValue=m.getValue().toString();
					output=verifyStatusCompleted(KeyValue,statusValue);
					forAllstatusHtml=forAllstatusHtml+output;
					break;
				case "AR_UP3":
					
					output=verifyStatusCompleted(KeyValue,statusValue);
					forAllstatusHtml=forAllstatusHtml+output;
					break;
					
				case "AR_UP4":
					System.out.println("AR_UP4 switch case");
					output=verifyStatusCompleted(KeyValue,statusValue);
					forAllstatusHtml=forAllstatusHtml+output;
					break;
				case "AR_UPDec":
					System.out.println("AR_UPDec switch case");
					verifyUP1ReqStatus(m.getValue().toString()); 
					break;
				case "AR_STPDec":
					verifySTPReqStatus(m.getValue().toString());
					break;
				case "AR_WFLaunch":
					System.out.println("AR_WFLaunch switch case");
					output=verifyStatusCompleted(KeyValue,statusValue);
					forAllstatusHtml=forAllstatusHtml+output;
					System.out.println("Inside AR_WFLaunch");
					break;
				case "AR_CloseFTD":
					verifyStatusCompleted(KeyValue,statusValue);
					forAllstatusHtml=forAllstatusHtml+output;
					break;
				case "DATALOCKERWF":
					verifyStatusCompleted(KeyValue,statusValue);
					forAllstatusHtml=forAllstatusHtml+output;
					break;
				case "AR_ContentUpdater":
					System.out.println("Inside AR_ContentUpdater");
					verifyStatusCompleted(KeyValue,statusValue);
					forAllstatusHtml=forAllstatusHtml+output;
					break;
				case "default":
					System.out.println("Not required for verification");
					break;
				}
			}
			updateStatusinExcel("Status_Table_Key", keys);
			updateStatusinExcel("Status_Table_Value", keyValues);
			System.out.println("Size............" + verifyStatus.size());
			if (verifyStatus.size() == 10) {
				updateStatusinExcel("DB_verification_Status", "Pass");
				Assert.assertTrue(true);
			} else {
				updateStatusinExcel("DB_verification_Status", "Fail");
				Assert.assertTrue(true);

			}
			
			System.out.println("All values------------------------------>"+forAllstatusHtml);
			printAllStatus(forAllstatusHtml);

		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			System.out.println("Null Pointer Exception");
		}
	}

	//@Daisy: All DB Methods to be contained in one method - with a case separation
	public void selectMessageFromDB(String MessageCode) throws Exception {

		DataBaseConnectivity dbcon = new DataBaseConnectivity();
		Statement sqlstatement = dbcon.createConnection();
		System.out.println("customerReferenceNumber" + customerReferenceNumber);

		String readRecordSQL = "select requestid,serviceid,messageid,requestmsg,responsemsg,sysmodifiedtime from EOPS_HUB_RB_SIT01.msgtxndetails where requestid="
				+ "'" + customerReferenceNumber + "'" + " and messageid=" + "'" + MessageCode + "'"
				+ "order by serviceid desc";

		System.out.println(readRecordSQL);
		ResultSet myResultSet = sqlstatement.executeQuery(readRecordSQL);
		while (myResultSet.next()) {
			if (MessageCode.equalsIgnoreCase("DLPK003")) {
				RequestSoapMessageInEOPS_HUB_RB_SIT01 = myResultSet.getString("requestmsg");
				System.out.println("Request Message--------------->>" + RequestSoapMessageInEOPS_HUB_RB_SIT01);
				ResponseSoapMessageInEOPS_HUB_RB_SIT01 = myResultSet.getString("responsemsg");
				System.out.println("Response------>" + ResponseSoapMessageInEOPS_HUB_RB_SIT01);
				updateStatusinExcel("DB_EOPStoICMPayload", RequestSoapMessageInEOPS_HUB_RB_SIT01);
				updateStatusinExcel("EopstoICMPayloadResponse", RequestSoapMessageInEOPS_HUB_RB_SIT01);

			} else if (MessageCode.equalsIgnoreCase("JMSDL_01")) {
				EopsToiBankingNotificationPayload = myResultSet.getString("requestmsg");
				updateStatusinExcel("EopsToiBankingNotificationPayload", EopsToiBankingNotificationPayload);
			}
		}
	}

	//@Daisy: Done!
	public void retrieveCustomerNumber() throws Exception {
		customerReferenceNumber = verifyContentFromSoapXml(EopsresponseAsString, "consumerRef");
		System.out.println(customerReferenceNumber);
	}

	//@Daisy : to be moved to Business Method
	public void verifySuccessMessage() throws Exception {
		String messageValue = verifyContentFromSoapXml(EopsresponseAsString, "message");
		if (messageValue.equalsIgnoreCase("Application Processed Successfully")) {
			
			StepDef.scenario.write("Response message Received------->"+messageValue);
			updateStatusinExcel("ResponseMessage", messageValue);	
		} else {
			StepDef.scenario.write("Response message Received------->"+messageValue);
			updateStatusinExcel("ResponseMessage", messageValue);	
		}
	}

	//@Daisy : to be moved to Business Method
	public void requestMessageFromDB() throws Exception {
		System.out.println("customerReferenceNumber -" + customerReferenceNumber);
		System.out.println("Request SOAP Message : " + RequestSoapMessageInEOPS_HUB_RB_SIT01);
		fetchallxmlTags(RequestSoapMessageInEOPS_HUB_RB_SIT01, EopstoICMPayload, "EopstoICMPayload_Key", "EopstoICMPayload_Value");
		
			}
	
	//@Daisy : To be moved to Business Method
	public void responseMessageFromDB() throws Exception {
		System.out.println("customerReferenceNumber -" + customerReferenceNumber);
		System.out.println(ResponseSoapMessageInEOPS_HUB_RB_SIT01);
		fetchallxmlTags(ResponseSoapMessageInEOPS_HUB_RB_SIT01, ICMtoEopsResponse, "ICMtoEopsRespPayload_Key", "ICMtoEopsRespPayload_Value");
	}

	//@Daisy : To be moved to Business Method
	public void NotifyMessageFromDB() throws Exception {
		System.out.println("Inside request message");
		System.out.println("customerReferenceNumber -" + customerReferenceNumber);
		System.out.println(RequestSoapMessageInEOPS_HUB_RB_SIT01);
		fetchallxmlTags(RequestSoapMessageInEOPS_HUB_RB_SIT01, RequestSoapMessageInEOPS, "EopsNotificationPayload_Key", "EopsNotificationPayload_Value");
	}

	//@Daisy: Sheet name to be dynamically addressed - Hardcoding to be removed
	public void updateStatusinExcel(String columnName, String valueToUpdate) throws FilloException {
		String strQuery;
		filloconnection = fillo.getConnection(FileUtilities.inputExcelDetails);
		if (!valueToUpdate.isEmpty()) {
			strQuery = "UPDATE Sheet2 SET " + columnName + "='" + valueToUpdate + "' " + "where SenarioID='"
					+ scenarioIdFromExcel + "'";
		} else {
			strQuery = "UPDATE Sheet2 SET " + columnName + "=null" + "where SenarioID='" + scenarioIdFromExcel + "'";
		}

		System.out.println("Query ---> " + strQuery);
		filloconnection.executeUpdate(strQuery);
		filloconnection.close();
	}

	//@Daisy : Please check to change all read to common method and all write to common method
	public Map<String, String> selectValueFromExcel(String name, String value, String scenarioId)
			throws FilloException, ParserConfigurationException, SAXException, IOException, TransformerException {
		Fillo fillo = new Fillo();
		scenarioIdFromExcel = scenarioId;
		Map<String, String> mapForInput = new HashMap<String, String>();
		Connection connection = fillo.getConnection(FileUtilities.inputExcelDetails);
		String strQuery = "Select * from Sheet2 where SenarioID='" + scenarioId + "'";
		System.out.println(strQuery);
		Recordset recordset = connection.executeQuery(strQuery);
		while (recordset.next()) {
			System.out.println(recordset.getField("InputValueChange_iBankingRequestPayload_Key"));
			ArrayList<String> tag = splitTheInput(recordset.getField("InputValueChange_iBankingRequestPayload_Key"));
			ArrayList<String> tagValue = splitTheInput(
					recordset.getField("InputValueChange_iBankingRequestPayload_Value"));
			if (tag.size() == tagValue.size()) {
				for (int i = 0; i < tag.size(); i++) {
					mapForInput.put(tag.get(i).toString(), tagValue.get(i).toString());
					update("pProcessServiceData", tag.get(i).toString(), tagValue.get(i).toString());
				}
			}

		}

		recordset.close();
		connection.close();
		return mapForInput;
	}

	//@Daisy : To be re-visited or removed
	public void update(String parentTagName, String TagName, String TagValue)
			throws ParserConfigurationException, SAXException, IOException, TransformerException {

		String filepath = FileUtilities.inputXmlPath;
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		Node parentNode = doc.getElementsByTagName(parentTagName).item(0);
		NodeList list = parentNode.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node node = list.item(i);
			// get the salary element, and update the value
			if (TagName.equals(node.getNodeName())) {
				node.setTextContent(TagValue);
			}
		}

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		transformer.transform(source, result);

	}

	//@Daisy : To be moved to common library / Utilities
	public static ArrayList<String> splitTheInput(String dataValue) {
		ArrayList<String> splitedValues = new ArrayList<String>();
		String[] valueFromExel = dataValue.split("\\|");
		for (String str : valueFromExel) {
			System.out.print(str);
			splitedValues.add(str);
		}
		return splitedValues;

	}

	//@Daisy : Done!
	public void fetchallxmlTags(String xmlasString,Map<String,String> mapName,String excelColumnNameforKey,String excelColumnNameforValue) throws Exception {

		InputStream inputStream = new ByteArrayInputStream(xmlasString.getBytes(Charset.forName("UTF-8")));
		XMLInputFactory inputFactory = XMLInputFactory.newFactory();
		XMLStreamReader reader = inputFactory.createXMLStreamReader(inputStream);
		inputFactory.setProperty(XMLInputFactory.IS_COALESCING, true);
		while (reader.hasNext()) {
			switch (reader.next()) {
			case XMLStreamConstants.START_ELEMENT:
				
				keyTag = reader.getName().toString();
				break;

			case XMLStreamConstants.END_ELEMENT:
				break;

			case XMLStreamConstants.CHARACTERS:
				
			case XMLStreamConstants.CDATA:
				
			case XMLStreamConstants.SPACE:
				keyTagValue = reader.getText().toString();
				
				if (!keyTagValue.trim().isEmpty()) {

					keyTagValue = keyTagValue.replaceAll("[\\\r\\\n]+", "");
					keyTagValue = keyTagValue.replaceAll("\\s", "");
					 putallxmltagsinMapandExcel(mapName,keyTag,keyTagValue,excelColumnNameforKey,excelColumnNameforValue);
					 keyDetailsUpdateinExcel=keyDetailsUpdateinExcel+keyTag+"|";
					 keyValueUpdateinExcel=keyValueUpdateinExcel+keyTagValue+"|";
				}
				break;
				
			}
			

		}
		 updateStatusinExcel(excelColumnNameforKey, keyDetailsUpdateinExcel);
		 updateStatusinExcel(excelColumnNameforValue, keyValueUpdateinExcel);		
		 printMapValues(mapName);

	}
    
	//@Daisy : Done!
	public void putallxmltagsinMapandExcel(Map<String,String> mapName,String key, String value,String excelKeyColumnName,String excelValueColumnName ) throws Exception {	
		mapName.put(key, value);	
	}
	
	//@Daisy : Done!
	public void printMapValues(Map<String,String> mapName)
	{
		for (Map.Entry<String, String> entry : mapName.entrySet()) 
		{
			
			System.out.println("Values updated in Map---->" + entry.getKey() + " : " + entry.getValue());
						
		}

	}


	
	public void reportlog(String Field,String ActualVal,String ExpectedVal,String status)

	
	       {
	              String htmlrep = 
	            		  	   "<html>" +
	            		  	   "<body>" +
	                           "<table border ='1'>" +
	                           "<tr>" +
	                           "<td>Field Name</td>" +
	                           "<td>Expected Result</td>" +
	                           "<td>Actual Result</td>" +
	                           "<td>Status</td>" +
	                           "</tr>"+
	                           "<tr>"+
	                           "<td>"+Field+"</td>"+
	                           "<td>"+ExpectedVal+"</td>"+
	                           "<td>"+ActualVal+"</td>"+
	                           "<td>"+status+"</td>"+
	                           "</tr>"+
	                           "</table>"+
	                           "</body>" +
	                           "</html>";              
	              StepDef.scenario.embed(htmlrep.getBytes(), "text/html");              
	       }
	
	public void printAllStatus(String outputValue)
	{
		String htmlrep = 
 		  	   "<html>" +
 		  	   "<body>" +
                "<table border ='1'>" +
                "<tr>" +
                "<td>Field Name</td>" +
                "<td>Expected Result</td>" +
                "<td>Actual Result</td>" +
                "<td>Status</td>" +
                "</tr>"+
                forAllstatusHtml+  
                "</table>"+
                "</body>" +
                "</html>";              
   StepDef.scenario.embed(htmlrep.getBytes(), "text/html");              
	System.out.println("hummmm hmmmm"+htmlrep);
	}
}



