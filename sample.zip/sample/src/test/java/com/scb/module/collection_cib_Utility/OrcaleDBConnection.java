package com.scb.module.collection_cib_Utility;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Properties;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import io.restassured.path.json.JsonPath;


public class OrcaleDBConnection {

	Connection con;
	Statement stmt=null;
	HashMap<String, Object> storeValue =null;
	ResultSet rs;
	public Properties prop_Db;
	ReadProperties getproperty = new ReadProperties();

	
	//DB connection Creation
	public Statement createConnection() throws Exception
	{
		Class.forName("oracle.jdbc.OracleDriver");  
		con=DriverManager.getConnection("jdbc:oracle:thin:@HKLPDURCM001.HK.STANDARDCHARTERED.COM:1621:SOHK1RCM","DDI","Scb_2019");  
		Statement	stmt=con.createStatement(); 

		return stmt;
	}
   //To check Reference ID is available in Ecollection DB

	public HashMap<String, Object> connectDBConnection(String sqlQuery ,String wherecondition) throws Exception
	{		
		stmt=createConnection();

		if(sqlQuery.contains("like"))
		{
			System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
			rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
		}
		else
		{
			System.out.println(sqlQuery+" '"+wherecondition+"' ");
			rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
		}
		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();

		while(rs.next())  
		{

			storeValue = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++)
			{
				storeValue.put(metadata.getColumnName(i), rs.getObject(i));
			}
		}
		con.close();
		return storeValue;



	}
	 //To check Row_Count_Verification in Ecollection DB for Positive

	public void rowCountVerification(String sqlQuery ,String wherecondition ) throws SQLException, Exception
	{


		stmt=createConnection();
		HashMap<String, Object> storeValue =null;

		if(sqlQuery.contains("like"))
		{
			System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
			rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
		}
		else
		{
			System.out.println(sqlQuery+" '"+wherecondition+"' ");
			rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
		}

		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();

		while(rs.next())  
		{

			storeValue = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++)
			{
				storeValue.put(metadata.getColumnName(i), rs.getObject(i));

			}
		}

		System.out.println();
		BigDecimal s =(BigDecimal)	storeValue.get("ROWCOUNT");

		if(s.toString().equals("1"))
		{
			System.out.println(" Count One");
		}
		else if(s.toString().equals("5"))
		{
			System.out.println("Count Five");
		}
		else
		{
			Assert.assertTrue("Row Size is not equal to as expected 1 but actual :"+storeValue.get("ROWCOUNT"), false);
		}	
	}

	//To check Row_Count_Verification in Ecollection DB for Negative
	
	public void negrowCountVerification(String sqlQuery ,String wherecondition ) throws SQLException, Exception
	{


		stmt=createConnection();
		HashMap<String, Object> storeValue =null;

		if(sqlQuery.contains("like"))
		{
			System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
			rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
		}
		else
		{
			System.out.println(sqlQuery+" '"+wherecondition+"' ");
			rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
		}

		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();

		while(rs.next())  
		{

			storeValue = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++)
			{
				storeValue.put(metadata.getColumnName(i), rs.getObject(i));

			}
		}

		System.out.println();
		BigDecimal s =(BigDecimal)	storeValue.get("ROWCOUNT");

		if(s.toString().equals("0"))
		{
			System.out.println(" Count Zero");
		}
		else if(s.toString().equals("3"))
		{
			System.out.println("Count Three");
		}
		else
		{
			Assert.assertTrue("Row Size is not equal to as expected 1 but actual :"+storeValue.get("ROWCOUNT"), false);
		}	
	}


	
	//DB connection Creation for TraditionalDBConnection
	
	public HashMap<String, Object> connectTraditionalDBConnection(String sqlQuery ,String wherecondition) throws Exception
	{             
		Class.forName("oracle.jdbc.OracleDriver");  
		con=DriverManager.getConnection("jdbc:oracle:thin:@//hklpdudas2a-scan.hk.standardchartered.com:1622/rcms_uat.hk.standardchartered.com","rcms","rcms_123");  
		stmt=con.createStatement();  

		if(wherecondition.equals("No Query"))
		{
			System.out.println(sqlQuery);
			rs=stmt.executeQuery(sqlQuery); 
		}
		else
		{
			if(sqlQuery.contains("like"))
			{
				System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
				rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
			}
			else
			{
				System.out.println(sqlQuery+" '"+wherecondition+"' ");
				rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
			}
		}

		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();

		while(rs.next())  
		{
			storeValue = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++)
			{
				storeValue.put(metadata.getColumnName(i), rs.getObject(i));
			}
		}
		con.close();
		return storeValue;
	}
	
	//To verify the Response STAGECODE in each DB module

	public void s2bapi_Res_code(String stagecode, String trackingid ) throws Throwable
	{
		prop_Db = getproperty.readProperties("DBQuery");
		boolean flag = false;
		stmt=createConnection();
		stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(
				"select * from RCMS_S2BAPI_RES_LOG where TRACKING_ID = '"+trackingid+"'");
		System.out.println(rs);
		while (rs.next()) {

			String code = rs.getString("STAGECODE");
			if (code.equals(stagecode))
			{
				System.out.println("-------ResponeCode-----"+code);
				Assert.assertTrue(true);
				flag=true;
				break;
			}	

		}
		if(flag==false)
		{
			Assert.assertTrue(false);
		}

	}
	
	
	//To check Row_Count_Verification in Ecollection DB for Negative
	public void rowCountVerificationNeg(String sqlQuery ,String wherecondition ) throws SQLException, Exception
	{


		stmt=createConnection();
		HashMap<String, Object> storeValue =null;

		if(sqlQuery.contains("like"))
		{
			System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
			rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
		}
		else
		{
			System.out.println(sqlQuery+" '"+wherecondition+"' ");
			rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
		}

		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();

		while(rs.next())  
		{

			storeValue = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++)
			{
				storeValue.put(metadata.getColumnName(i), rs.getObject(i));

			}
		}

		System.out.println();
		BigDecimal s =(BigDecimal)	storeValue.get("ROWCOUNT");

		if(s.toString().equals("1"))
		{
			System.out.println(" Count One");
		}
		else if(s.toString().equals("5"))
		{
			System.out.println(" Count Five");
		}
		else if(s.toString().equals("0"))
		{
			System.out.println(" Count Zero");
		}
		else
		{
			Assert.assertTrue("Row Size is not equal to as expected 1 but actual :"+storeValue.get("ROWCOUNT"), false);
		}	
	}

	//To check Row_Count_Verification in Ecollection DB for HealthCheck
	
	public BigDecimal rowCountVerificationOnHealthCheck(String sqlQuery ,String wherecondition ) throws SQLException, Exception
	{


		stmt=createConnection();
		HashMap<String, Object> storeValue =null;

		if(sqlQuery.contains("like"))
		{
			System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
			rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
		}
		else
		{
			System.out.println(sqlQuery+" '"+wherecondition+"' ");
			rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
		}

		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();

		while(rs.next())  
		{

			storeValue = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++)
			{
				storeValue.put(metadata.getColumnName(i), rs.getObject(i));

			}
		}


		BigDecimal s =(BigDecimal)	storeValue.get("ROWCOUNT");
		return s;


	}

	//To get DB row count for the Query 
	
	public int rowCountVerification_withSize(String dbName,String sqlQuery ,String wherecondition) throws SQLException, Exception
	{

		if(dbName.equals("RCMS"))
		{
			stmt=createConnection();
		}
		else if(dbName.equals("GCG"))
		{
			Class.forName("oracle.jdbc.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@//hklpdudas2a-scan.hk.standardchartered.com:1622/GCG_UAT_SG_02.hk.standardchartered.com","GCG_HK_GENERAL_APP","GCG_HK_GENERAL_APP_123");
			stmt=con.createStatement();
		}
		else
		{
			Class.forName("oracle.jdbc.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@//hklpdudas2a-scan.hk.standardchartered.com:1622/rcms_uat.hk.standardchartered.com","rcms","rcms_123");  
			stmt=con.createStatement(); 
		}
		
		HashMap<String, Object> storeValue =null;
		int rowCount =0 ;
		if(wherecondition.equals("No Query"))
		{
			System.out.println(sqlQuery);
			rs=stmt.executeQuery(sqlQuery); 
		}
		else
		{
			if(sqlQuery.contains("like"))
			{
				System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
				rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
			}
			else
			{
				System.out.println(sqlQuery+" '"+wherecondition+"' ");
				rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
			}
		}
		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();

		while(rs.next())  
		{
			rowCount = rowCount+1;
			storeValue = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++)
			{
				storeValue.put(metadata.getColumnName(i), rs.getObject(i));
			}
		}

		return rowCount;
	}
	
	
	//DB connection Creation for GCG_DBConnection
	
	
	public HashMap<String, Object> connectGCGDBConnection(String sqlQuery ,String wherecondition) throws Exception
	{             
		Class.forName("oracle.jdbc.OracleDriver");  
		con=DriverManager.getConnection("jdbc:oracle:thin:@//hklpdudas2a-scan.hk.standardchartered.com:1622/GCG_UAT_SG_02.hk.standardchartered.com","GCG_HK_GENERAL_APP","GCG_HK_GENERAL_APP_123");
		stmt=con.createStatement();

		if(wherecondition.equals("No Query"))
		{
			System.out.println(sqlQuery);
			rs=stmt.executeQuery(sqlQuery); 
		}
		else
		{
			if(sqlQuery.contains("like"))
			{
				System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
				rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
			}
			else
			{
				System.out.println(sqlQuery+" '"+wherecondition+"' ");
				rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
			}
		}

		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();

		while(rs.next())  
		{
			storeValue = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++)
			{
				if(metadata.getColumnName(i).equals("OUT_MSG")){
					storeValue.put(metadata.getColumnName(i), rs.getString(i).toString());
				}
				else{
					storeValue.put(metadata.getColumnName(i), rs.getObject(i));
				}
				
			}
		}
		con.close();
		return storeValue;
	}
	
	//Checking the row Count
	
	public BigDecimal rowCountcheck(String sqlQuery ,String wherecondition ) throws SQLException, Exception
	{


		stmt=createConnection();
		HashMap<String, Object> storeValue =null;

		if(sqlQuery.contains("like"))
		{
			System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
			rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
		}
		else
		{
			System.out.println(sqlQuery+" '"+wherecondition+"' ");
			rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
		}

		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();

		while(rs.next())  
		{

			storeValue = new HashMap<String, Object>(columnCount);
			for(int i=1;i<=columnCount;i++)
			{
				storeValue.put(metadata.getColumnName(i), rs.getObject(i));

			}
		}

		System.out.println();
		BigDecimal s =(BigDecimal)	storeValue.get("ROWCOUNT");

		if(s.toString().equals("1"))
		{
			System.out.println(" Count One");
		}
		else if(s.toString().equals("5"))
		{
			System.out.println("Count Five");
		}
		else
		{
			Assert.assertTrue("Row Size is not equal to as expected 1 but actual :"+storeValue.get("ROWCOUNT"), false);
		}
		return s;	
	}

}
