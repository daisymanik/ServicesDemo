package com.scb.module.collection_cib;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Properties;
import com.scb.module.collection_cib_Utility.ReadProperties;

public class DataBaseConnectivity {


		Connection con;
		Statement stmt=null;
		HashMap<String, Object> storeValue =null;
		ResultSet rs;
		public Properties prop_Db;
		ReadProperties getproperty = new ReadProperties();

		public Statement createConnection() throws Exception
		{
			Class.forName("oracle.jdbc.OracleDriver");  
			con=DriverManager.getConnection("jdbc:oracle:thin:@//HKLPDUDASB-SCAN.HK.STANDARDCHARTERED.COM:1622/EOPS_UAT_01.hk.standardchartered.com","EOPSVIEW","EOPSVIEW_123");  
			Statement	stmt=con.createStatement(); 
			return stmt;
		}


		public HashMap<String, Object> connectDBConnection(String sqlQuery ,String wherecondition) throws Exception
		{		
			stmt=createConnection();

			if(sqlQuery.contains("like"))
			{
				System.out.println(sqlQuery+" '%\""+wherecondition+"\"%'");
				rs=stmt.executeQuery(sqlQuery+" '%\""+wherecondition+"\"%'");  
			}
			else
			{
				System.out.println(sqlQuery+" '"+wherecondition+"' ");
				rs=stmt.executeQuery(sqlQuery+" '"+wherecondition+"' ");
			}
			ResultSetMetaData metadata = rs.getMetaData();
			int columnCount = metadata.getColumnCount();

			while(rs.next())  
			{

				storeValue = new HashMap<String, Object>(columnCount);
				for(int i=1;i<=columnCount;i++)
				{
					storeValue.put(metadata.getColumnName(i), rs.getObject(i));
				}
			}
			con.close();
			return storeValue;

		}
}
