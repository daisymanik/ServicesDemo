//jsonConstruct


package com.scb.module.collection_cib_Utility;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;

import com.codoid.products.exception.FilloException;
import com.scb.module.collection_cib.StepDef;



public class JsonUtility {

	public  JSONObject requestParams= new JSONObject();
	JSONObject debtormsg = new JSONObject();
	JSONObject instructedAmountmsg = new JSONObject();
	CommonUtils commonUtils = new CommonUtils();
	StepDef stepobj = new StepDef();
	DataProvider dataprovider1 = new DataProvider();
	
	//API request Payload for RTDDI
	
	public JSONObject jsonDDI(HashMap<String,String> getData)

	{
		requestParams.put("referenceId", getData.get("referenceId")) ;

		instructedAmountmsg.put("currencyCode", getData.get("currencyCode")) ;
		instructedAmountmsg.put("amount", getData.get("amount")) ;
		requestParams.put("instructedAmount", instructedAmountmsg) ;

		requestParams.put("mandateId", getData.get("mandateId")) ;

		debtormsg.put("name", getData.get("debtor_name"));

		requestParams.put("debtor", debtormsg) ;

		return requestParams;
	}

	//API request Payload for RTDDI Health check for OFFUS
	public JSONObject jsonDDIOffusHealth(HashMap<String,String> getData)

	{
		requestParams.put("referenceId", getData.get("referenceId")+"123Offus") ;

		instructedAmountmsg.put("currencyCode", getData.get("currencyCode")) ;
		instructedAmountmsg.put("amount", getData.get("amount")) ;
		requestParams.put("instructedAmount", instructedAmountmsg) ;

		requestParams.put("mandateId", "MA0080016") ;

		debtormsg.put("name", getData.get("debtor_name"));

		requestParams.put("debtor", debtormsg) ;

		return requestParams;
	}

	//API request Payload for OutwardCreditInitiation
	
	public JSONObject jsonOutwardCreditInitiation(HashMap<String,String> getData)
	{
		JSONObject parentObject = new JSONObject();
		JSONObject headerObject = new JSONObject();
		JSONObject instructionObject = new JSONObject();
		JSONObject instructionAmount = new JSONObject();
		JSONObject debtorName = new JSONObject();
		JSONObject debtorAccID = new JSONObject();
		JSONObject financialInstitutionsub = new JSONObject();
		JSONObject financialInstitutionParent = new JSONObject();
		JSONObject postalAddressCountry = new JSONObject();
		JSONObject creditorSub = new JSONObject();
		JSONObject CreditorpostalAddressSub = new JSONObject();
		JSONObject CreditorfinancialInstitutionParent = new JSONObject();
		JSONObject CreditorfinancialInstitutionSub = new JSONObject();
		JSONObject creditorAccount = new JSONObject();
		

		if(!getData.get("messageSender").equals("Skipped"))
		{
		headerObject.put("messageSender", getData.get("messageSender"));
		}
		
		headerObject.put("messageId", getData.get("messageId"));
		if(!getData.get("countryCode").equals("Skipped"))
		{
		headerObject.put("countryCode", getData.get("countryCode"));
		}
		
		if(getData.get("timeStamp").isEmpty())
		{
		headerObject.put("timestamp", "");
		}
		else if(getData.get("timeStamp").equals("Normal"))
		{
			headerObject.put("timestamp", commonUtils.getDateTime()); //"2019-04-30T08:32:10Z"
			//headerObject.put("timestamp", commonUtils.getDateTime());
		}
		else if(getData.get("timeStamp").equals("Skipped"))
		{
			//headerObject.put("timestamp", getData.get("timeStamp"));
		}
		else if(getData.get("timeStamp").equals("Skipped"))
		{
			//headerObject.put("timestamp", getData.get("timeStamp"));
		}
		else if(getData.get("timeStamp").matches("\\d+"))
		{
			headerObject.put("timestamp", getData.get("timeStamp"));
		}
		else
		{
			headerObject.put("timestamp", getData.get("timeStamp"));
		}
		
		if(!getData.get("paymentTypePreference").equals("Skipped"))
		{
			instructionObject.put("paymentTypePreference", getData.get("paymentTypePreference"));
		}
		
		//PaymentTimeStamp Condition
		if(getData.get("paymentTimeStamp").isEmpty())
		{
			instructionObject.put("paymentTimestamp", "");
		}
		else if(getData.get("paymentTimeStamp").equals("Normal"))
		{
			instructionObject.put("paymentTimestamp", commonUtils.getDateTime());
		}
		else if(getData.get("paymentTimeStamp").equals("Skipped"))
		{
			//headerObject.put("paymentTimestamp", getData.get("timeStamp"));
		}
		else if(getData.get("paymentTimeStamp").matches("\\d+"))
		{
			headerObject.put("paymentTimestamp", getData.get("paymentTimeStamp"));
		}
		else
		{
			instructionObject.put("paymentTimestamp", commonUtils.getDateTime());
		}
		if(getData.get("requiredExecutionDate").equals("FutureDate"))
		{
			instructionObject.put("requiredExecutionDate", "2019-10-10");
		}
		else if(getData.get("requiredExecutionDate").equals("PastDate"))
		{
			instructionObject.put("requiredExecutionDate", "2019-01-10");
		}
		else if(getData.get("requiredExecutionDate").equals("InvaildDate"))
		{
			instructionObject.put("requiredExecutionDate", "6/23/2019");
		}
		else
		{
			instructionObject.put("requiredExecutionDate", commonUtils.getDate());
		}
		
		//Currency Code
		if(getData.get("currencyCode").isEmpty())
		{
		headerObject.put("currencyCode", "");
		}
		else if(getData.get("currencyCode").equals("Normal"))
		{
			headerObject.put("currencyCode", commonUtils.getDateTime());
		}
		else if(getData.get("currencyCode").equals("Skipped"))
		{
			//headerObject.put("paymentTimestamp", getData.get("timeStamp"));
		}
		else
		{
			instructionAmount.put("currencyCode", getData.get("currencyCode"));
		}
		
		if(getData.get("amount").isEmpty())
		 {
			 instructionAmount.put("amount", "");
		 }
		else if(!getData.get("amount").equals("Skipped"))
		{
			
			 instructionAmount.put("amount", Double.parseDouble(getData.get("amount")));//getData.get("amount")
		}
		
		instructionObject.put("amount", instructionAmount);

		 if(!getData.get("referenceId").equals("Skipped"))
			{
			 instructionObject.put("referenceId", getData.get("referenceId"));
			}
		 
		
		 if(!getData.get("purpose").equals("Skipped"))
			{
				instructionObject.put("purpose", getData.get("purpose"));
			}
	
		 if(!getData.get("paymentType").equals("Skipped"))
			{
			 instructionObject.put("paymentType", getData.get("paymentType"));
			}
		
		 if(!getData.get("debtor_name").equals("Skipped"))
			{
			 debtorName.put("name", getData.get("debtor_name"));
			}

		
		instructionObject.put("debtor", debtorName);

		 if(!getData.get("debtorAccount_id").equals("Skipped"))
			{
			 debtorAccID.put("id", getData.get("debtorAccount_id"));
			}
		
		instructionObject.put("debtorAccount",debtorAccID);
		
		if(!getData.get("debtor_postal_country").equals("Skipped"))
		{
			postalAddressCountry.put("country", getData.get("debtor_postal_country"));
		}
	
		
		
		financialInstitutionsub.put("postalAddress", postalAddressCountry);

		//financialInstitutionsub.put("BIC", getData.get("debtor_BIC"));
		//financialInstitutionsub.put("name", "Standard Chartered Bank");	
		financialInstitutionParent.put("financialInstitution", financialInstitutionsub);

		if(!getData.get("debtor_clearingSystemId").equals("Skipped"))
		{
			financialInstitutionParent.put("clearingSystemId", getData.get("debtor_clearingSystemId"));
		}
		
		instructionObject.put("debtorAgent", financialInstitutionParent);

		if(!getData.get("creditorname").equals("Skipped"))
		{
			creditorSub.put("name", getData.get("creditorname"));
		}
		
		instructionObject.put("creditor",creditorSub);

		CreditorpostalAddressSub.put("country", getData.get("Creditor_postal_country"));
		CreditorfinancialInstitutionSub.put("postalAddress", CreditorpostalAddressSub);

		//CreditorfinancialInstitutionSub.put("BIC", getData.get("creditor_BIC"));

		if(getData.get("creditor_name").isEmpty())
		 {
			CreditorfinancialInstitutionSub.put("name", "");
		 }
		else if(!getData.get("creditor_name").equals("Skipped"))
		{
			CreditorfinancialInstitutionSub.put("name", getData.get("creditor_name"));
		}
		CreditorfinancialInstitutionParent.put("financialInstitution", CreditorfinancialInstitutionSub);


		if(!getData.get("creditor_clearingSystemId").equals("Skipped"))
		{
			CreditorfinancialInstitutionParent.put("clearingSystemId", getData.get("creditor_clearingSystemId"));
		}
		
		instructionObject.put("creditorAgent", CreditorfinancialInstitutionParent);

		if(!getData.get("creditoracc_id").equals("Skipped"))
		{
			creditorAccount.put("id", getData.get("creditoracc_id"));
		}
		creditorAccount.put("identifierType", getData.get("creditoracc_identifierType"));
		instructionObject.put("creditorAccount", creditorAccount);

		parentObject.put("header", headerObject);
		parentObject.put("instruction", instructionObject);



		return parentObject;
	}
	
	//API Credit_Status_Request Payload for OutwardCreditInitiation

	public JSONObject outwardCreditStatusRequest(HashMap<String,String> getData)
	{
		JSONObject outwardCreditStatus = new JSONObject();
		JSONArray clientReferenceIds = new JSONArray();

		clientReferenceIds.put(getData.get("clientReferenceId"));
		outwardCreditStatus.put("clientReferenceIds", clientReferenceIds);


		return outwardCreditStatus;
	}
	//API Credit_Status_Request Payload for OutwardCreditInitiation_Negative
	
	public JSONObject outwardCreditStatusRequest_Neg(HashMap<String,String> getData)
	{
		JSONObject outwardCreditStatus = new JSONObject();
		JSONArray clientReferenceIds = new JSONArray();

		clientReferenceIds.put(getData.get("referenceId"));
		outwardCreditStatus.put("clientReferenceIds", clientReferenceIds);


		return outwardCreditStatus;
	}

	
	//API request Payload for EDDA
	
	public JSONObject jsonEDDA(HashMap<String,String> getData,String tcID, String tcSheet) throws ParseException
	{
		JSONObject parentObject = new JSONObject();
		JSONObject debACT = new JSONObject();
		JSONObject creACT = new JSONObject();
		JSONObject debAGE = new JSONObject();
		JSONObject creAGE = new JSONObject();
		JSONObject creditor = new JSONObject();
		JSONObject debitor = new JSONObject();
		JSONObject contactDetails = new JSONObject();
		JSONObject payLimit = new JSONObject();
		JSONObject debtorIdentificationDocumentIds = new JSONObject();
		String refID = "";
		LocalDate today = LocalDate.now();
		LocalTime time = LocalTime.now();
		Random random = new Random();
		if(!getData.get("TD_REF_ID").equalsIgnoreCase("Empty")){

			if(getData.get("TD_REF_ID").equalsIgnoreCase("Numeric")){
				refID = String.format("%6d",random.nextInt((999999-111111)+1))+String.format("%4d",random.nextInt((9999-1111)+1))+String.format("%02d", today.getDayOfMonth())+String.format("%02d", today.getMonthValue())+today.getYear()+String.format("%02d", time.getHour())+String.format("%02d", time.getMinute())+String.format("%02d", time.getSecond())+String.format("%5d",random.nextInt((99999-11111)+1))+String.format("%6d",random.nextInt((999999-111111)+1));
				refID = refID.replaceAll(" ", "0");
			}
			else if(getData.get("TD_REF_ID").equalsIgnoreCase("Alpha")){
				String word = "";
				for (int i = 1; i < 28; i++) {
					word = word + ((char)('A' + random.nextInt(26)));
				}
				refID = "AUTOEDDA"+word;
			}
			else if(getData.get("TD_REF_ID").equalsIgnoreCase("Combined")){
				refID = "AUTO@EDDA@"+String.format("%02d", today.getDayOfMonth())+String.format("%02d", today.getMonthValue())+"@"+today.getYear()+String.format("%02d", time.getHour())+String.format("%02d", time.getMinute())+String.format("%02d", time.getSecond())+String.format("%09d",random.nextInt((999999999-111111111)+1));
				refID = refID.replaceAll(" ", "0");
			}
			else if(getData.get("TD_REF_ID").equalsIgnoreCase("Null")){
				refID = "";
			}
			else if(getData.get("TD_REF_ID").equalsIgnoreCase("Normal")){
				refID = "AUTOEDDA"+String.format("%02d", today.getDayOfMonth())+String.format("%02d", today.getMonthValue())+today.getYear()+String.format("%02d", time.getHour())+String.format("%02d", time.getMinute())+String.format("%02d", time.getSecond())+String.format("%08d",random.nextInt((99999999-11111111)+1));
				refID = refID.replaceAll(" ", "0");
			}
			else if(getData.get("TD_REF_ID").equalsIgnoreCase("Less")){
				refID = "AUTOEDDA"+String.format("%02d", today.getDayOfMonth())+String.format("%02d", today.getMonthValue())+String.format("%02d", time.getHour())+String.format("%02d", time.getMinute())+String.format("%02d", time.getSecond())+String.format("%08d",random.nextInt((99999-11111)+1));
				refID = refID.replaceAll(" ", "0");
			}
			else
			{
				refID = getData.get("TD_REF_ID");
			}
			parentObject.put("referenceId",refID);
			
			try {
				dataprovider1.writeExcelData(tcID, tcSheet, "clientIdentifier",refID);
			} catch (FilloException | IOException e1) {
				e1.printStackTrace();
			}
		}
		
		if(!getData.get("TD_DEBACT_ID").equalsIgnoreCase("Empty")){
			if(getData.get("TD_DEBACT_ID").equalsIgnoreCase("Null")){
				debACT.put("id","");
			}
			else{
				debACT.put("id",getData.get("TD_DEBACT_ID"));
			}
		}
		if(!getData.get("TD_DEBACT_TYPE").equalsIgnoreCase("Empty")){
			if(getData.get("TD_DEBACT_TYPE").equalsIgnoreCase("Null")){
				debACT.put("identifierType","");
			}
			else{
				debACT.put("identifierType",getData.get("TD_DEBACT_TYPE"));
			}
		}
		
		parentObject.put("debtorAccount", debACT);
		
		if(!getData.get("TD_CRDACT_ID").equalsIgnoreCase("Empty")){
			if(getData.get("TD_CRDACT_ID").equalsIgnoreCase("Null")){
				creACT.put("id","");
			}
			else{
				creACT.put("id",getData.get("TD_CRDACT_ID"));
			}
		}
		if(!getData.get("TD_CRDACT_TYPE").equalsIgnoreCase("Empty")){
			if(getData.get("TD_CRDACT_TYPE").equalsIgnoreCase("Null")){
				creACT.put("identifierType","");
			}
			else{
				creACT.put("identifierType",getData.get("TD_CRDACT_TYPE"));
			}
		}
		parentObject.put("creditorAccount", creACT);
		
		if(!getData.get("TD_DEBACT_CLRID").equalsIgnoreCase("Empty")){
			if(getData.get("TD_DEBACT_CLRID").equalsIgnoreCase("Null")){
				debAGE.put("clearingSystemId","");
			}
			else{
				debAGE.put("clearingSystemId",getData.get("TD_DEBACT_CLRID"));
			}
			parentObject.put("debtorAgent", debAGE);
		}
		
		if(!getData.get("TD_CRDACT_CLRID").equalsIgnoreCase("Empty")){
			if(getData.get("TD_CRDACT_CLRID").equalsIgnoreCase("Null")){
				creAGE.put("clearingSystemId","");
			}
			else{
				creAGE.put("clearingSystemId", getData.get("TD_CRDACT_CLRID"));
			}
			parentObject.put("creditorAgent", creAGE);
		}
		
		if(!getData.get("TD_CRDACT_LEGAL").equalsIgnoreCase("Empty")){
			if(getData.get("TD_CRDACT_LEGAL").equalsIgnoreCase("Null")){
				creditor.put("legalEntityId","");
			}
			else{
				creditor.put("legalEntityId", getData.get("TD_CRDACT_LEGAL"));
			}
		}
		if(!getData.get("TD_CRDACT_NAME").equalsIgnoreCase("Empty")){
			if(getData.get("TD_CRDACT_NAME").equalsIgnoreCase("Null")){
				creditor.put("name","");
			}
			else{
				creditor.put("name", getData.get("TD_CRDACT_NAME"));
			}
		}
		parentObject.put("creditor", creditor);
		
		if(!getData.get("TD_DEBACT_MBN").equalsIgnoreCase("Empty")){
			String mbNumber;
			if(getData.get("TD_DEBACT_MBN").equalsIgnoreCase("Null")){
				mbNumber = "";
				contactDetails.put("mobileNumber", mbNumber);
				debitor.put("contactDetails", contactDetails);
			}
			else if(getData.get("TD_DEBACT_MBN").equalsIgnoreCase("Invalid")){
				mbNumber = "137687";
				contactDetails.put("mobileNumber", mbNumber);
				debitor.put("contact", contactDetails);
			}
			else{
				mbNumber = "/MOBN/"+getData.get("TD_DEBACT_MBN");
				contactDetails.put("mobileNumber", mbNumber);
				debitor.put("contactDetails", contactDetails);
			}
			
		}
		if(!getData.get("TD_DEBACT_NAME").equalsIgnoreCase("Empty")){
			if(getData.get("TD_DEBACT_NAME").equalsIgnoreCase("Null")){
				debitor.put("name","");
			}
			else{
				debitor.put("name", getData.get("TD_DEBACT_NAME"));
			}
		}
		parentObject.put("debtor", debitor);
		
		if(!getData.get("TD_MAX_TXNAMT").equalsIgnoreCase("Empty")){
			if(getData.get("TD_MAX_TXNAMT").equalsIgnoreCase("Null")){
				payLimit.put("maximumTransactionAmount","");
			}
			else{
				payLimit.put("maximumTransactionAmount", getData.get("TD_MAX_TXNAMT"));
			}
		}
		if(!getData.get("TD_MAX_BATAMT").equalsIgnoreCase("Empty")){
			if(getData.get("TD_MAX_BATAMT").equalsIgnoreCase("Null")){
				payLimit.put("maximumBatchAmount","");
			}
			else{
				payLimit.put("maximumBatchAmount", getData.get("TD_MAX_BATAMT"));
			}
		}
		if(!getData.get("TD_PREODICITY").equalsIgnoreCase("Empty")){
			if(getData.get("TD_PREODICITY").equalsIgnoreCase("Null")){
				payLimit.put("periodicity","");
			}
			else{
				payLimit.put("periodicity", getData.get("TD_PREODICITY"));
			}
		}
		parentObject.put("paymentLimit", payLimit);
		
		if(!getData.get("TD_HKDID").equalsIgnoreCase("Empty")){
			if(getData.get("TD_HKDID").equalsIgnoreCase("Null")){
				debtorIdentificationDocumentIds.put("HKId","");
			}
			else{
				debtorIdentificationDocumentIds.put("HKId",getData.get("TD_HKDID"));
			}
			parentObject.put("debtorIdentificationDocumentIds", debtorIdentificationDocumentIds);
		}else if(!getData.get("TD_PASSPORT").equalsIgnoreCase("Empty")){
			if(getData.get("TD_PASSPORT").equalsIgnoreCase("Null")){
				debtorIdentificationDocumentIds.put("passport","");
			}
			else{
				debtorIdentificationDocumentIds.put("passport",getData.get("TD_PASSPORT"));
			}
			parentObject.put("debtorIdentificationDocumentIds", debtorIdentificationDocumentIds);
		}
		
		if(!getData.get("TD_EXP_DATE").equalsIgnoreCase("Empty")){
			String expDate="";
			Date date = new Date();  
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String strDate= formatter.format(date); 
			Calendar c = Calendar.getInstance();
			c.setTime(formatter.parse(strDate));
			if(getData.get("TD_EXP_DATE").equalsIgnoreCase("Future")){
				c.add(Calendar.YEAR, 2);
				expDate = formatter.format(c.getTime());
				parentObject.put("expiryDate",expDate);
			}
			else if(getData.get("TD_EXP_DATE").equalsIgnoreCase("Today")){
				parentObject.put("expiryDate",strDate);
			}
			else if(getData.get("TD_EXP_DATE").equalsIgnoreCase("Yesterday")){
				c.add(Calendar.DAY_OF_MONTH, -1);
				expDate = formatter.format(c.getTime());
				parentObject.put("expiryDate",expDate);
			}
			else if(getData.get("TD_EXP_DATE").equalsIgnoreCase("Null")){
				parentObject.put("expiryDate",expDate);
			}
			else if(getData.get("TD_EXP_DATE").equalsIgnoreCase("TimeStamp")){
				expDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()).replace(" ", "T");
				parentObject.put("expiryDate",expDate);
			}
			else if(getData.get("TD_EXP_DATE").equalsIgnoreCase("Invalid")){
				expDate = new SimpleDateFormat("dd-MM-YYYY").format(new Date());
				parentObject.put("expiryDate",expDate);
			}
			else{
				parentObject.put("expiryDate",getData.get("TD_EXP_DATE"));
			}
		}
		
		if(!getData.get("TD_EFF_DATE").equalsIgnoreCase("Empty")){
			String expDate="";
			Date date = new Date();  
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String strDate= formatter.format(date); 
			Calendar c = Calendar.getInstance();
			c.setTime(formatter.parse(strDate));
			if(getData.get("TD_EFF_DATE").equalsIgnoreCase("Future")){
				c.add(Calendar.YEAR, 2);
				expDate = formatter.format(c.getTime());
				parentObject.put("effectiveDate",expDate);
			}
			else if(getData.get("TD_EFF_DATE").equalsIgnoreCase("Today")){
				parentObject.put("effectiveDate",strDate);
			}
			else if(getData.get("TD_EFF_DATE").equalsIgnoreCase("Yesterday")){
				c.add(Calendar.DAY_OF_MONTH, -1);
				expDate = formatter.format(c.getTime());
				parentObject.put("effectiveDate",expDate);
			}
			else if(getData.get("TD_EFF_DATE").equalsIgnoreCase("Null")){
				parentObject.put("effectiveDate",expDate);
			}
			else if(getData.get("TD_EFF_DATE").equalsIgnoreCase("TimeStamp")){
				expDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(new Date()).replace(" ", "T");
				parentObject.put("effectiveDate",expDate);
			}
			else if(getData.get("TD_EFF_DATE").equalsIgnoreCase("Invalid")){
				expDate = new SimpleDateFormat("dd-MM-YYYY").format(new Date());
				parentObject.put("effectiveDate",expDate);
			}
			else{
				parentObject.put("effectiveDate",getData.get("TD_EFF_DATE"));
			}
		}
		
		if(!getData.get("TD_DEBACT_REF").equalsIgnoreCase("Empty")){
			if(getData.get("TD_DEBACT_REF").equalsIgnoreCase("Null")){
				parentObject.put("debtorReference","");
			}
			else{
				parentObject.put("debtorReference",getData.get("TD_DEBACT_REF"));
			}
		}
		
		parentObject.put("currencyCode",getData.get("TD_CURR_CODE"));
		if(!getData.get("TD_MANDATE_TYPE").equalsIgnoreCase("Empty")){
			if(getData.get("TD_MANDATE_TYPE").equalsIgnoreCase("Null")){
				parentObject.put("mandateType","");
			}
			else{
				parentObject.put("mandateType",getData.get("TD_MANDATE_TYPE"));
			}
		}
		
		if(!getData.get("TD_TYPE").equalsIgnoreCase("Empty")){
			if(getData.get("TD_TYPE").equalsIgnoreCase("Null")){
				parentObject.put("type","");
			}
			else{
				parentObject.put("type",getData.get("TD_TYPE"));
			}
		}

		return parentObject;
	}
	
	//API request Payload for kibanaOCLog for Outword_Credit

	public JSONObject kibanaOCLog(HashMap<String,String> getData, String logger, String message)
	{
		JSONObject queryParentObj = new JSONObject();
		JSONObject boolObj = new JSONObject();
		JSONObject boolObj1 = new JSONObject();
		JSONObject mustObj = new JSONObject();
		JSONObject matchObj = new JSONObject();
		JSONObject messageObj = new JSONObject();
		JSONObject queryObj = new JSONObject();
		JSONArray array = new JSONArray();
		
		JSONObject matchObj11 = new JSONObject();
		JSONObject messageObj11 = new JSONObject();
		JSONObject queryObj11 = new JSONObject();
		
		JSONObject matchObj12 = new JSONObject();
		JSONObject messageObj12 = new JSONObject();
		JSONObject queryObj12 = new JSONObject();
		
		
		queryObj.put("query", getData.get("paymentIdentifier")); //getData.get("clientReferenceId")
		messageObj.put("message", queryObj);
		matchObj.put("match", messageObj);
		array.put(matchObj);
		
		
		queryObj11.put("query", logger);
		messageObj11.put("logger", queryObj11);
		matchObj11.put("match", messageObj11);
		array.put(matchObj11);
	/*	mustObj11.put("must", array11);
		boolObj12.put("bool", mustObj11);
		queryParentObj.put("query", boolObj12);*/
		
		queryObj12.put("query", message);
		queryObj12.put("operator", "and");
		messageObj12.put("message", queryObj12);
		matchObj12.put("match", messageObj12);
		array.put(matchObj12);
		
		
		mustObj.put("must", array);
		boolObj.put("bool", mustObj);
		queryParentObj.put("query", boolObj);
		
		return queryParentObj;
	}
}



