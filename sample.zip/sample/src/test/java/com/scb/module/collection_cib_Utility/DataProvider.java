//Excel_Utils

package com.scb.module.collection_cib_Utility;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class DataProvider
{

	
Fillo fillo=new Fillo();
Connection connection;


//Write the value into Excel

public void writeExcelData(String testCaseID, String sheetName,String Columnname, String columnvalue) throws FilloException, IOException
{
	
	connection=fillo.getConnection(System.getProperty("user.dir")+"/TestData/Book1.xlsx");

	String strQuery="Update "+sheetName+" Set "+Columnname+"='" +columnvalue +"' where TestCaseID='" +testCaseID +"' ";
	 
	connection.executeUpdate(strQuery);
	 
	connection.close();
		
}

//Read the values form Excel 

public HashMap<String,String> extractExcelData(String testCaseID, String sheetName) throws FilloException, IOException
{

	HashMap<String, String> excelHashMapValues= new HashMap<>();

connection=fillo.getConnection(System.getProperty("user.dir")+"/TestData/Book1.xlsx");


String strQuery="Select * from "+sheetName+" where TestCaseID='" +testCaseID +"'and Status='YES'";

Recordset recordset=connection.executeQuery(strQuery);

while(recordset.next())
{
ArrayList<String> ColCollection = recordset.getFieldNames();
int Iter;
int size = ColCollection.size();
for (Iter=0 ; Iter<= (size-1) ; Iter++)
{
String ColName = ColCollection.get(Iter);
//System.out.println(ColName);
String ColValue = recordset.getField(ColName);
//System.out.println(ColValue);
//HashMap<String, String> excelHashMapValues = new HashMap <String, String>();
excelHashMapValues.put(ColName, ColValue); 
}
}
recordset.close();
connection.close();

return excelHashMapValues;
}

//To check whether the files is received through Solace
public boolean chkconnection(String testCaseID) throws FilloException, IOException
{
       boolean chkFlag = false;
       connection=fillo.getConnection(System.getProperty("user.dir")+"/TestData/Book1.xlsx");
       String strQuery="Select TD_Solace_Processed from  RCMSStandalone where TestCaseID='" +testCaseID +"'";

       Recordset recordset=connection.executeQuery(strQuery);
       
       recordset.next();
       if(recordset.getField("TD_Solace_Processed").equals("Received"))
       {
              chkFlag=  true;
       }
       
       connection.close();
       return chkFlag;
}

//To check whether the files is received through Solace
public boolean chkconnection(String testCaseID, String sheetName) throws FilloException, IOException
{
       boolean chkFlag = false;
       connection=fillo.getConnection(System.getProperty("user.dir")+"/TestData/Book1.xlsx");

       String strQuery="Select * from "+sheetName+" where TestCaseID='" +testCaseID +"'";
       System.out.println(strQuery);
       Recordset recordset=connection.executeQuery(strQuery);
       
       recordset.next();
       if(recordset.getField("Status").equals("YES"))
       {
              chkFlag=  true;       
       }
       
       connection.close();
       return chkFlag;
}

//Write the value into Excel to Health check report
public void writeExcelData(String sheetName,String Columnname, String columnvalue,String healthCheckheader,String Flagvalue) throws FilloException, IOException
{
	
	connection=fillo.getConnection(System.getProperty("user.dir")+"/TestData/Book1.xlsx");
	//String strQuery="Update "+sheetName+" Set "+Columnname+"='" +columnvalue+"' where Checkcodes like "+ checkvalue +"";
	
	String strQuery="Update "+sheetName+" Set "+Columnname+"='" +columnvalue +"' where "+ healthCheckheader +" = '"+Flagvalue+"' ";
	 System.out.println("########"+strQuery);
	connection.executeUpdate(strQuery);
	 
	connection.close();
		
}

//Store the values into excel to display in to Jenkin report web page

public Recordset htmlreportread(String testCaseID, String sheetName)throws FilloException
{

     connection=fillo.getConnection(System.getProperty("user.dir")+"/TestData/Book1.xlsx");

     String strQuery="Select * from "+sheetName+" where TestCaseID='" +testCaseID +"'";

     Recordset recordset=connection.executeQuery(strQuery);
   
	return recordset;
  
}

}
