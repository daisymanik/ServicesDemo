package com.scb.module.collection_cib;

import java.io.File;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Scanner;

import org.json.JSONObject;
import java.util.Iterator;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

import io.restassured.path.json.JsonPath;

public class TestJavaRun {
	
	
 	 
	public static void main(String args[]) throws Exception


	{	boolean c = true;
		
		File jFile = new File(System.getProperty("user.dir")+"/src/test/resources/OutwardCredit_Json/Test.json");
		String content = new Scanner(jFile).useDelimiter("\\Z").next(); 
		JSONObject obj = new JSONObject(content);
		JsonPath jp = new JsonPath(obj.toString());
		JsonPath s2BAPI_scPay_AdapterRequest = null;
		
	int num =	Integer.parseInt(jp.getString("hits.total"));
		
	if(num>0)
	{
			for(int i=0;i<num;i++)
			{
				if(c)
				{
				String scPay_Adapter_Req =	jp.getString("hits.hits["+i+"]._source.message");
				System.out.println(scPay_Adapter_Req);
				 String[] fn = scPay_Adapter_Req.split("CBS Request:");
				 	 s2BAPI_scPay_AdapterRequest = new JsonPath(fn[1]);	
				 	 try
				 	 {
				if( s2BAPI_scPay_AdapterRequest.getString("data.debitacc.debitidtype").equals("H") )
				{
					c=false;
				}
				 	 }
				 	 catch(NullPointerException e)
				 	 {
				 		System.out.println("111"+s2BAPI_scPay_AdapterRequest.getString("data.creditacc.creditidtype"));
				 	 }
				
				}
			}
	}
	else
	{
		System.out.println("Log count not greater than one");

	}
}
}

	
