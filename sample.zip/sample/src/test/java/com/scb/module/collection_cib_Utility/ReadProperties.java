package com.scb.module.collection_cib_Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.junit.Test;

public class ReadProperties {

	// Properties Files Reader
	
	public Properties readProperties(String PropertyFileName) throws FileNotFoundException
	{
		File source=new File(System.getProperty("user.dir")+"/src/test/resources/"+PropertyFileName+".properties");
		FileInputStream fis=new FileInputStream(source);
		Properties properties=new Properties();
		try {
			properties.load(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	return properties;
		
	}
	

}
