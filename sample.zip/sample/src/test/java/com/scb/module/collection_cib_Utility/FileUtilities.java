package com.scb.module.collection_cib_Utility;

import java.io.File;

public class FileUtilities {

	public static final String inputXmlPath=new File("src/test/resources/InputDetails/iBankingToEops.xml").getAbsolutePath(); 
	public static final String inputExcelDetails=new File("src/test/resources/ExcelDataDetails/TestData.xlsx").getAbsolutePath();
	public static final String inputPropertyDetails=new File("src/test/resources/InputDetails/inputTestdataDetails.properties").getAbsolutePath();
	
}
