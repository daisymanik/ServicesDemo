package com.scb.module.collection_cib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.io.IOUtils;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.codoid.products.fillo.Connection;
import com.google.common.util.concurrent.Service.State;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class JavaTestExample {
	static String url;
	Connection con = null;
	static Map<String, String> mapforValue;
	public static FileInputStream input;
	public static Response response;
	public static String customerRefNumber;
	public static int responseCode;
	public static String responseValueasString;
	public static String responseAsString;
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		input = new FileInputStream(new File("C:\\Users\\1601017\\Desktop\\RestAPI\\STP Request and Response XML Files\\FromIBankingToEops\\iBankingToEops.xml"));
		//JavaTestExample.updatexmlDataValue();
		RestAssured.baseURI = "http://10.23.208.182:8080";
		response = RestAssured.given().header("Content-type", "text/xml").and().body(IOUtils.toString(input, "UTF-8"))
				.when().post("/eopsServiceProvider/ProcessService");
		customerRefNumber=JavaTestExample.verifyContentFromResponse("consumerRef");
		responseCode=response.getStatusCode();
		responseAsString=response.asString();
		
		
		System.out.println("customerRefNumber - "+ customerRefNumber);
		System.out.println("responseCode - "+responseCode);
		JavaTestExample.selectValuesFromDB(customerRefNumber);
		//JavaTestExample.selectValuesFromDB(customerRefNumber);
	//	JavaTestExample.selectMessageFromDB(customerRefNumber);
	//	getFullNameFromXml(responseValueasString, "qualification");	
	}

	public static String verifyContentFromResponse(String tagNametoVerify) throws Exception {
		
		System.out.println(response.asString());
		List<String> output = getFullNameFromXml(response.asString(),tagNametoVerify);
		String[] strarray = new String[output.size()];
		output.toArray(strarray);
		String tagValue=removeOpenandClosebracket(Arrays.toString(strarray));
		return tagValue;
	}

	public boolean verifyResponseCode() {
		int responseCode = response.getStatusCode();
		if (responseCode == 200) {
			System.out.println(responseCode);
			return true;
		} else {
			return false;
		}

	}

	public static String removeOpenandClosebracket(String inputString)
	{
		String output=inputString;
		output=output.replace("[", "");
		output=output.replace("]", "");
		return output;
		
	}
	
	public static Document loadXMLString(String response) throws Exception {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(response));
		return db.parse(is);
	}

	public static List<String> getFullNameFromXml(String response, String tagName) throws Exception {
		Document xmlDoc = loadXMLString(response);
		NodeList nodeList = xmlDoc.getElementsByTagName(tagName);
		System.out.println("NodeListValue - "+nodeList.toString());
		List<String> ids = new ArrayList<String>(nodeList.getLength());
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node x = nodeList.item(i);
			ids.add(x.getFirstChild().getNodeValue());
			System.out.println("Node List Values"+nodeList.item(i).getFirstChild().getNodeValue());
		}
		return ids;
	}
	
	
	public static void updatexmlDataValue() throws Exception
	{

		String filepath = "C:\\Users\\1601017\\Desktop\\RestAPI\\STP Request and Response XML Files\\FromIBankingToEops\\iBankingToEops.xml";
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		Node staff = doc.getElementsByTagName("firstName").item(0);
		staff.setTextContent("Ulaganathan");

	}

	public static void selectValuesFromDB(String costomerRefId) throws Exception {
		DataBaseConnectivity dbcon = new DataBaseConnectivity();
		Statement sqlstatement = dbcon.createConnection();
		String readRecordSQL = "SELECT t.taskid,t.txrefno,t.statuscode,t.stepname,t.steplabel,t.selectedresponse,t.userresponse,t.responsecode,t.stepresponses,t.countrycode,t.processid,t.enqueuetime,t.locktime,t.modifiedtime,t.elapsedtime,t.lockeduser,t.channel,t.modifieduserid,t.queuename,t.scantime,t.isolatedregion,t.CATEGORY,t.laststepname,t.referrallist,t.seckey FROM eops_hub_rb_sit01.task t WHERE t.txrefno="
				+ "'"+"SCC578PK10A1310519076661"+"'"
				+ "ORDER BY taskid DESC";
		System.out.println(readRecordSQL);
		ResultSet myResultSet = sqlstatement.executeQuery(readRecordSQL);
		while (myResultSet.next()) {
			String stepName = myResultSet.getString("stepname");
			String stepresponse = myResultSet.getString("selectedresponse");
			//mapforValue.put(stepName, stepresponse);
			
			System.out.println("Record values: " + myResultSet.getString("stepname"));
			System.out.println("Record values: " + myResultSet.getString("selectedresponse"));
		}
	}
	
	
	public static void selectMessageFromDB(String costomerRefId) throws Exception {
		DataBaseConnectivity dbcon = new DataBaseConnectivity();
		Statement sqlstatement = dbcon.createConnection();
		String readRecordSQL = "select requestid,serviceid,messageid,requestmsg,responsemsg, sysmodifiedtime from EOPS_HUB_RB_SIT01.msgtxndetails where requestid="
				+ "'SCC578PK10A1310519076661' and messageid='JMSDL_01'"
				+ "order by serviceid desc";
		System.out.println(readRecordSQL);
		ResultSet myResultSet = sqlstatement.executeQuery(readRecordSQL);
		
		while (myResultSet.next()) {
			mapforValue = new HashMap<String, String>();
			System.out.println("Message Id " + myResultSet.getString("messageid"));
			System.out.println("Request Message " + myResultSet.getString("requestmsg"));
			System.out.println("responsemsg "+myResultSet.getString("responsemsg"));			
		}
	}
}
