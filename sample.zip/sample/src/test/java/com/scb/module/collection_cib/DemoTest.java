package com.scb.module.collection_cib;

import java.util.ArrayList;

public class DemoTest {

	public static void main(String[] args) {
		int a=10,b=20;
		if(a>110||a>111 && b>0||b>10)
		{
			System.out.println("Test");
		}
			
	}

}
