package com.scb.module.collection_cib.glue;

import java.io.File;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;


public class TestJava {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Hello for Test Java");
		File jFile = new File(System.getProperty("user.dir") + "/src/test/resources/Gcgacceptance.xml");
		@SuppressWarnings("resource")
		String msgCNT = new Scanner(jFile).useDelimiter("\\Z").next();
		WebDriver driver = new HtmlUnitDriver();
		driver.get("http://gcgsimulator:gcgsimulator@10.23.219.75:5501/scbHKFPSimulator/PostHKFPSMessages.dsp");
		Select oSelect = new Select(driver.findElement(By.id("msgType")));
		oSelect.selectByValue("HKFPS_Outward_DDA_Response");
		WebElement msgVal = driver.findElement(By.id("message"));
		msgVal.sendKeys(msgCNT);
		WebElement submit = driver.findElement(By.xpath("//*[@value='Send']"));
		submit.click();
		WebElement suscess = driver.findElement(By.xpath("//*[text()='HKFPS_Outward_DDA_Response payload send to GCG Successfully']"));
		System.out.println(suscess.isDisplayed());
		driver.quit();
	}

}
