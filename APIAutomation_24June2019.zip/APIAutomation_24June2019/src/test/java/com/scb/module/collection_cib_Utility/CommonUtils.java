package com.scb.module.collection_cib_Utility;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Scanner;
import java.util.TimeZone;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.Select;

import com.codoid.products.exception.FilloException;
import com.scb.module.collection_cib.StepDef;
import com.scb.module.collection_cib_Utility.DataProvider;
import com.standardchartered.genie.model.GenieScenario;

import static io.restassured.RestAssured.given;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.FilterableRequestSpecification;
import io.restassured.specification.RequestSpecification;

public class CommonUtils {

	
	
	static JsonUtility jsonutil = new JsonUtility();
	static JSONObject jsonObj;
	public String strHTMLval = null;
	public String strHTMLvalJen= null;
	public String strHTMLvalJenONUSPASS= null;
	

	public Response response;

	ReadProperties getproperty = new ReadProperties();
	Properties prop_Reource;
	public String[] extractfields(DataProvider dataProvider, String testCaseID, String sheetName,String Columnname ) throws Exception {

		DataProvider dp = new DataProvider();
		HashMap<String, String> value =	dp.extractExcelData(testCaseID, sheetName);

		String value1=value.get(Columnname);
		System.out.println(value1);
		String s[] =value1.split("\\|");
		return s;	
	}

// Checking the type of the value Ex[AlphaNumeric,Alphabet, etc...]
	
	public boolean typeCheck(String Type,String inputvalue)
	{
		boolean b=false;

		if(inputvalue!=null && !inputvalue.isEmpty())
		{

			if(Type.equals("alphaNumeric"))
			{
				b =	Pattern.matches("[a-zA-Z0-9]+", inputvalue);
			}
			else if(Type.equals("numeric"))
			{
				b =	Pattern.matches("[0-9]+", inputvalue);
			}
			else if(Type.equals("alphabet"))
			{
				b =	Pattern.matches("[a-zA-Z]+", inputvalue);
			}
			else if(Type.equals("capitalAlphabet"))
			{
				b =	Pattern.matches("[A-Z]+", inputvalue);
			}
			else if(Type.equals("smallAlphabet"))
			{
				b =	Pattern.matches("[a-z]+", inputvalue);
			}

			else if(Type.equals("dateTimeFormat"))
			{
				b=Pattern.matches("^\\d{4}-(0[1-9]|1[012])-([012]\\d|3[01])T([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d).[\\d]{3}.*", inputvalue);

			}
			else if(Type.equals("dateFormat - YYYYMMDD"))
			{
				b=Pattern.matches("^\\d{4}(0[1-9]|1[012])([012]\\d|3[01])", inputvalue);
			} 
			else if(Type.equals("UTER"))
			{
				b=Pattern.matches("\\w{8}-\\w{4}-\\w{4}-\\w{4}-\\w{12}", inputvalue);
			}
			
		}
		 
		else if(Type.equals("dateFormat - YYYYMMDD"))
					{
						b=Pattern.matches("^\\d{4}(0[1-9]|1[012])([012]\\d|3[01])", inputvalue);
					} 
		else if(Type.equals("dateFormat - YYYY-MM-DD"))
		{
			b=Pattern.matches("^\\d{4}-(0[1-9]|1[012])-([012]\\d|3[01])", inputvalue);
		}  
		else if(Type.equals("dateFormat - Dispatcher_Request"))
		{
			b=Pattern.matches("^\\d{4}-(0[1-9]|1[012])-([012]\\d|3[01])T([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)", inputvalue);
		}
		else
		{
			Assert.assertTrue("Given Input value is Null/Not matched :"+inputvalue, false);
		}

		return b;
	}

	//Checking the excepted Length of the value 
	
	public boolean lengthCheck(int expectedlimit, String inputvalue)
	{
		boolean b=false;

		if(inputvalue!=null && !inputvalue.isEmpty())
		{
			if(expectedlimit==inputvalue.length())
			{

				b=true;
				System.out.println("Excepted Length of the value is "+expectedlimit+"Actual is:"+inputvalue.length());
			}
			else
			{
				b=false;
			}
		}
		else
		{
			Assert.assertTrue("Given Input value is Null/Not matched :"+inputvalue, false);
		}
		return b;

	}
	//Checking the excepted and minimum Length of the value 
	public boolean lengthCheck(int expectedlimit,int minimumlimit, String inputvalue)
	{
		boolean b=false;

		if(inputvalue!=null && !inputvalue.isEmpty())
		{
			int length = inputvalue.length();
			if(expectedlimit<length && minimumlimit>length)
			{
				b=true;
			}
			else
			{
				b=false;
			}
		}
		else
		{
			Assert.assertTrue("Given Input value is Null/Not matched :"+inputvalue, false);
		}
		return b;

	}

	public boolean lengthCheckDecimal(int expectedlimit_numeric,int expectedlimit_decimal, String inputvalue)
	{
		boolean b=false;

		if(inputvalue!=null && !inputvalue.isEmpty())
		{
			String splitvalue[] = inputvalue.split("\\.");



			if(expectedlimit_numeric==splitvalue[0].length() && expectedlimit_decimal==splitvalue[1].length())
			{
				b=true;
			}
			else
			{
				b=false;
			}
		}
		else
		{
			Assert.assertTrue("Given Input value is Null/Not matched :"+inputvalue, false);
		}
		return b;

	}
// Rest API Request  for RDDI
	public static RequestSpecification  ddiInitiateRequest(HashMap<String,String> getdata){

		Logger logger = Logger.getLogger(StepDef.class);
		jsonObj=jsonutil.jsonDDI(getdata);

		RequestSpecification	request = given().header("Content-Type","application/json").headers("GroupId", getdata.get("groupID")).body(jsonObj.toString());
		request.that().log().all(); 

		return request;

	}

	// Validating the API response fields. If any new field comes in the response or any field missed in the response the function will assert it.
	
	public boolean amountfieldValidation(int expectedlimit_numeric,int expectedlimit_decimal, String inputvalue)
	{
		boolean b=false;

		if(inputvalue!=null && !inputvalue.isEmpty())
		{
			String splitvalue[] = inputvalue.split("\\.");
			if(splitvalue.length < 2)
			{
				if(expectedlimit_numeric>=splitvalue[0].length())
				{
					int amtVal = Integer.parseInt(splitvalue[0]);
					if(amtVal>0)
					{
						b=true;
					}
				}
				else
				{
					b=false;
				}
			}
			else
			{
				if(expectedlimit_numeric>=splitvalue[0].length() && expectedlimit_decimal==splitvalue[1].length())
				{
					int amtVal = Integer.parseInt(splitvalue[0]);
					if(amtVal>0)
					{
						b=true;
					}
				}
				else
				{
					b=false;
				}
			}
		}
		else
		{
			Assert.assertTrue("Given Input value is Null/Not matched :"+inputvalue, false);
		}
		return b;

	}

//Creating HTML RCMS log table and Embedded into Genie report
	public void reportlog(GenieScenario genieScenario ,String Field,Object ActualVal,String ExpectedVal,String status)

	{
		{
			String htmlrep = "<html>" +
					"<body>" +
					"<table border ='1'>" +
					"<tr>" +
					"<td>Field Name</td>" +
					"<td>Expected Result</td>" +
					"<td>Actual Result</td>" +
					"<td>Status</td>" +
					"</tr>"+
					"<tr>"+
					"<td>"+Field+"</td>"+
					"<td>"+ExpectedVal+"</td>"+
					"<td>"+ActualVal+"</td>"+
					"<td>"+status+"</td>"+
					"</tr>"+
					"</table>"+
					"</body>" +
					"</html>";
			genieScenario.embed(htmlrep.getBytes(), "text/html");
		}
	}
	
	//Creating HTML RCMS log table and Embedded into Genie report
	public void writeReport(GenieScenario scenario, Object Comments,String jsonValue,String status)
	{
		String htmlrep = "<html>" +
				"<body>" +
				"<table border ='1'>" +
				"<tr>" +
				"<td>Comments</td>" +
				"<td>jsonValue</td>" +
				"<td>Status</td>" +
				"</tr>"+
				"<tr>"+
				"<td>"+Comments+"</td>"+
				"<td>"+jsonValue+"</td>"+
				"<td>"+status+"</td>"+
				"</tr>"+
				"</table>"+
				"</body>" +
				"</html>";
		scenario.embed(htmlrep.getBytes(), "text/html");
	}
	//Creating HTML RCMS log table and Embedded into Genie report
	public void concatHTMLstring(String fieldName, Object expectedVal, String actValue, String status, boolean clrFlag)
	{
		if(clrFlag)
		{
			strHTMLval = "<html>" +
					"<body>" +
					"<table border ='1'>" +
					"<tr>" +
					"<td>Field Name</td>" +
					"<td>Expected Value</td>" +
					"<td>Actual Value</td>" +
					"<td>Status</td>" +
					"</tr>";
		}
		else
		{
			strHTMLval = strHTMLval+"<tr>"+
					"<td>"+fieldName+"</td>"+
					"<td>"+expectedVal+"</td>"+
					"<td>"+actValue+"</td>"+
					"<td>"+status+"</td>"+
					"</tr>";
		}

	}
	//Creating HTML RCMS log table and Embedded into Genie report
	public void embedHTML(GenieScenario scenario)
	{
		String strwrHTML = strHTMLval+
				"</table>"+
				"</body>" +
				"</html>";
		scenario.embed(strwrHTML.getBytes(), "text/html");
	}

	//Log assert check and creating HTML RCMS log table and Embedded into Genie report
	public void assertcheck(GenieScenario scenario,String fieldName, Object expectedVal, String actValue)
	{
		if(expectedVal.equals(actValue))
		{
			concatHTMLstring(fieldName, expectedVal,actValue,"PASS",false);
			Assert.assertTrue(true);  
		}
		else
		{
			concatHTMLstring(fieldName, expectedVal,actValue,"FAIL",false);
			embedHTML(scenario);
			Assert.assertTrue(false);  
		}  
	}

	//Validating the Data and time format
	public String getDateTime()
	{
		String dateTime = null;
		try
		{
			Date date = new Date();
			SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss'Z'");
			dateformat.setTimeZone(TimeZone.getTimeZone("UTC"));
			dateTime=dateformat.format(date);

		}
		catch(Exception e)
		{
			e.getMessage().toString();
		}
		return dateTime;
	}
	
	public String getDate()
	{
		String getdate = null;
		try
		{
			Date date = new Date();
			SimpleDateFormat dateformat = new SimpleDateFormat("yyyy-MM-dd");
			dateformat.setTimeZone(TimeZone.getTimeZone("UTC"));
			getdate=dateformat.format(date);

		}
		catch(Exception e)
		{
			e.getMessage().toString();
		}
		return getdate;
	}
	
	// Rest API Request for OutwardCredit
	public static RequestSpecification  outwardCreditInitiateRequest(HashMap<String,String> getdata){

		Logger logger = Logger.getLogger(StepDef.class);
		JSONObject	outwardCreditjsonObj=jsonutil.jsonOutwardCreditInitiation(getdata);

		RequestSpecification	request = given().header("Content-Type","application/json").headers("GroupId", getdata.get("groupID")).
				body(outwardCreditjsonObj.toString());

		request.that().log().all(); 

		return request;

	}
	// Rest API Request for EDDA
	public static RequestSpecification  eddaInitiateRequest(GenieScenario genieScenario,HashMap<String,String> getdata,String testCaseID,String sheetName) throws ParseException{
		Logger logger = Logger.getLogger(StepDef.class);
		jsonObj=jsonutil.jsonEDDA(getdata,testCaseID,sheetName);

		RequestSpecification	request = given().header("Content-Type","application/json").headers("GroupId", getdata.get("groupID")).
				body(jsonObj.toString());
		request.that().log().all(); 

		FilterableRequestSpecification frs = (FilterableRequestSpecification)request; 
		Object obj = frs.getBody(); 
		String requestbody=String.valueOf(obj); 

		logger.info(" EDDA S2BAPI Initiation Request: "+requestbody);
		genieScenario.write("EDDA S2BAPI Initiation Request "+requestbody);

		return request;

	}

	// Rest API Endpoint creation in Linux server to validate the JSON logs
	public String getLog_Server(String path, String fileName) throws FileNotFoundException
	{
		prop_Reource = getproperty.readProperties("Endpoint_Resource");
		RestAssured.baseURI = prop_Reource.getProperty("EDDA_Log");
		RestAssured.useRelaxedHTTPSValidation(); 
		response = given().when() // response.body().jsonPath().getString("clientIdentifier")
				.get(prop_Reource.getProperty("EDDA_Log_Get") + path+"/"+fileName);
		
		if(response.asString().equals("File Not Found")){
			Assert.assertTrue("File Not Found", false);
		}
		
		return response.asString();

	}


	//Creating HTML Web page to show the Jenkin job execution status on runtime.
	public void jenkin_Report( String Functional_flow,String attention, String SPOC,boolean clrFlag)
    {
			if(clrFlag)
			{
				strHTMLvalJen = "<html>" +
		                  "<body>" +
		                  "<table border ='1'>" +
		                  "<caption>Note:&nbsp;&nbsp;Need attention from below teams for looking in to failure for ON-US/OFF-US RT DDI Sanity.</caption>"+
		                  "<tr>" +
		                  "<td>Functional flow</td>" +
		                  "<td>Application need attention</td>" +
		                  "<td>SPOC</td>" +
		                  "</tr>"+"<tr>"+
                        "<td>"+Functional_flow+"</td>"+
                        "<td>"+attention+"</td>"+
                        "<td>"+SPOC+"</td>"+
                        "</tr>";
			}
			else
			{
				strHTMLvalJen = strHTMLvalJen+"<tr>"+
                      
                        "<td>"+Functional_flow+"</td>"+
                        "<td>"+attention+"</td>"+
                        "<td>"+SPOC+"</td>"+
                        "</tr>";
			}
          
    }
	//Creating HTML Web page to show the Jenkin job execution status on runtime.
	public void JenkinHTML(GenieScenario scenario) throws IOException
    {
           String strwrHTMLJen1 = strHTMLvalJen+
                     "</table>"+
                     "</body>" +
                  "</html>";
           
           File file1 = new File(System.getProperty("user.dir")+"/HTML");
           boolean isDirectoryCreated = file1.mkdir();

           if (isDirectoryCreated) {
                  System.out.println("successfully made");
           } else {
                  deleteDir(file1);  // Invoke recursive method
                  file1.mkdir();       
           }
           
           File file = new File(System.getProperty("user.dir")+"/HTML/HealthCheck.html");
           file.createNewFile();

           BufferedWriter bw = new BufferedWriter(new FileWriter(file));
           bw.write(strwrHTMLJen1);
           bw.flush();
           bw.close();
           scenario.embed(strwrHTMLJen1.getBytes(), "text/html");
    }
	//Creating HTML Web page to show the Jenkin job execution status on runtime.
	public void jenkin_ReportONUSPASS( String FunctionName, String Status,String referenceId,String Application,String Description,String SPOC, boolean clrFlag)
    {   
		
		if(Status.equals("PASSED"))
		{
			if(clrFlag)
			{
				
				
				strHTMLvalJenONUSPASS = "<html>" +
		                  "<body>" +
		                  "<table border ='1',cellpadding='10',width='800'>" +
		                  "<tr>" +
		                  "<td>Functional flow</td>" +
		                  "<td>Sanity Status</td>" +
		                  "<td>ReferenceId</td>" +
		                  "<td>Team to Check</td>" +
		                  "<td>Issue Description</td>" +
		                  "<td>SPOC</td>" +
		                 
		                  "</tr>"+"<tr>"+
                        "<td>"+FunctionName+"</td>"+
                        "<td bgcolor='#00FF00'>"+Status+"</td>"+
                        "<td>"+referenceId+"</td>"+
                        "<td>"+Application+"</td>"+
                        "<td>"+Description+"</td>"+
                        "<td>"+SPOC+"</td>"+
                        
                        "</tr>";
				
				
			}
			else
			{
				strHTMLvalJenONUSPASS = strHTMLvalJenONUSPASS+"<tr>"+
                      
                        "<td>"+FunctionName+"</td>"+
                        "<td bgcolor='#00FF00'>"+Status+"</td>"+
                        "<td>"+referenceId+"</td>"+
                        "<td>"+Application+"</td>"+
                        "<td>"+Description+"</td>"+
                        "<td>"+SPOC+"</td>"+
                        "</tr>";
			}
		} 
		else{
		
			if(clrFlag)
			{
				
				
				strHTMLvalJenONUSPASS = "<html>" +
		                  "<body>" +
		                  "<table border ='1',cellpadding='10',width='800'>" +
		                  "<tr>" +
		                  "<td>Functional flow</td>" +
		                  "<td>Sanity Status</td>" +
		                  "<td>ReferenceId</td>" +
		                  "<td>Team to Check</td>" +
		                  "<td>Issue Description</td>" +
		                  "<td>SPOC</td>" +
		                 
		                  "</tr>"+"<tr>"+
                        "<td>"+FunctionName+"</td>"+
                        "<td bgcolor='#FF0000'>"+Status+"</td>"+
                        "<td>"+referenceId+"</td>"+
                        "<td>"+Application+"</td>"+
                        "<td>"+Description+"</td>"+
                        "<td>"+SPOC+"</td>"+
                        "</tr>";
				
				
			}
			else
			{
				strHTMLvalJenONUSPASS = strHTMLvalJenONUSPASS+"<tr>"+
                      
                        "<td>"+FunctionName+"</td>"+
                        "<td bgcolor='#FF0000'>"+Status+"</td>"+
                        "<td>"+referenceId+"</td>"+
                        "<td>"+Application+"</td>"+
                        "<td>"+Description+"</td>"+
                        "<td>"+SPOC+"</td>"+
                        "</tr>";
			}
		}
    }
	 
	//Creating HTML Web page to show the Jenkin job execution status on runtime.
	public void JenkinHTMLONUSPASS(GenieScenario scenario) throws IOException
    {
           String strHTMLvalJenONUSPASS1 = strHTMLvalJenONUSPASS+
                     "</table>"+
                     "</body>" +
                  "</html>";
           
           File file1 = new File(System.getProperty("user.dir")+"/HTML");
           boolean isDirectoryCreated = file1.mkdir();

           if (isDirectoryCreated) {
                  System.out.println("successfully made");
           } else {
                  deleteDir(file1);  // Invoke recursive method
                  file1.mkdir();       
           }
           
           File file = new File(System.getProperty("user.dir")+"/HTML/HealthCheck.html");
           file.createNewFile();

           BufferedWriter bw = new BufferedWriter(new FileWriter(file));
           bw.write(strHTMLvalJenONUSPASS1);
           bw.flush();
           bw.close();
           scenario.embed(strHTMLvalJenONUSPASS1.getBytes(), "text/html");
    }
	
	//Delete the HTML Web page for every execution
	public void deleteDir(File dir) {
        File[] files = dir.listFiles();

        for (File myFile: files) {
            if (myFile.isDirectory()) {  
                deleteDir(myFile);
            } 
            myFile.delete();

        }
    }

	// Storing the API request to compare with other JSON logs.
	public String requestBody(RequestSpecification request){
		FilterableRequestSpecification frs = (FilterableRequestSpecification)request; 
		Object obj = frs.getBody(); 
		return String.valueOf(obj); 
	}
	
	@SuppressWarnings("resource")
	public String getContent_File(String Path) throws Exception{
		File jFile = new File(Path);
		String content = new Scanner(jFile).useDelimiter("\\Z").next();
		return content;
	}
	
	
	public boolean push_GCG(String MSG,String reCat) throws Exception{
		boolean flg = false;
		WebDriver driver = new HtmlUnitDriver();
		driver.get("http://gcgsimulator:gcgsimulator@10.23.219.75:5501/scbHKFPSimulator/PostHKFPSMessages.dsp");
		Select oSelect = new Select(driver.findElement(By.id("msgType")));
		oSelect.selectByValue(reCat);
		WebElement msgVal = driver.findElement(By.id("message"));
		msgVal.sendKeys(MSG);
		WebElement submit = driver.findElement(By.xpath("//*[@value='Send']"));
		submit.click();
		WebElement suscess = driver.findElement(By.xpath("//*[text()='HKFPS_Outward_DDA_Response payload send to GCG Successfully']"));
		if(suscess.isDisplayed()){
			flg=true;
		}
		driver.quit();
		return flg;
	}
	
}
