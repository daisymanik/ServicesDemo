package com.scb.module.collection_cib_Utility;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;

import javax.xml.stream.XMLStreamReader;

import javax.xml.transform.Transformer;

import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;

import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;


import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.scb.module.collection_cib.DataBaseConnectivity;
import com.scb.module.collection_cib.StepDef;
import com.standardchartered.genie.model.v1_0.fragment.Scenario;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class SoapXMLParser {
	public Scenario scenario;
	FileInputStream input;
	public Response response;
	public String customerReferenceNumber = "";
	public String EopsresponseAsString = "";
	public String RequestSoapMessageInEOPS_HUB_RB_SIT01 = "";
	public String ResponseSoapMessageInEOPS_HUB_RB_SIT01 = "";
	public String EopsToiBankingNotificationPayload = "";
	public String scenarioIdFromExcel = "";
	public String keyTag = "";
	public String keyTagValue = "";
	public String keyDetailsUpdateinExcel="";
	public String keyValueUpdateinExcel="";
	public String forAllstatusHtml="";
	public String testcaseId="";
	public String sheetName="";
	public Map<String, String> cdataInputasMap = new HashMap<String, String>();
	public Map<String, String> iBankingRequest = new HashMap<String, String>();
	public Map<String, String> eopsresponse = new HashMap<String, String>();
	public Map<String, String> statusmap = new HashMap<String, String>();
	public Map<String,String> RequestSoapMessageInEOPS=new HashMap<String, String>();
	public Map<String, String> ICMtoEopsResponse=new HashMap<String,String>();
	public Map<String,String> EopstoICMPayload=new HashMap<String,String>();
	public Map<String, String> requestDetails = new HashMap<String, String>();
	public Map<String, String> responseDetails = new HashMap<String, String>();
	public Map<String, String> cDataDetails=new HashMap<String, String>();
	public Map<String, String> expectedTaskStatusDetails=new HashMap<String, String>();
	Logger logger = Logger.getLogger(SoapXMLParser.class);
	Fillo fillo = new Fillo();
	Connection filloconnection;
	CommonFunctions common=new CommonFunctions();
	public void baseUrlDetails() {

		try {
		//	System.out.println(common.readProperties(FileUtilities.inputPropertyDetails, "BaseUrl"));
		//	RestAssured.baseURI=common.readProperties(FileUtilities.inputPropertyDetails, "BaseUrl");
		RestAssured.baseURI = "http://10.23.208.182:8080";
			StepDef.scenario.write("End Point Details");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	//@Daisy: Function to be converted as most dynamic - should be able to change any value
	public void updateThePayloadValues() throws Exception
	{
		
			FileInputStream fisTargetFile = new FileInputStream(FileUtilities.inputXmlPath);
			String iBankingRequestAsString = IOUtils.toString(fisTargetFile, "UTF-8");
			fetchallxmlTags(iBankingRequestAsString, iBankingRequest,"iBankingRequestPayload_Key","iBankingRequestPayload_Value");
			//FileReader reader = new FileReader(FileUtilities.inputXmlPath);
			input = new FileInputStream(FileUtilities.inputXmlPath);
			response = RestAssured.given().header("Content-type", "text/xml").and()
					.body(IOUtils.toString(input, "UTF-8")).when().post("/eopsServiceProvider/ProcessService");
			EopsresponseAsString = response.asString();
			System.out.println("Response as String---------->>>>>" + response.asString());
			retrieveCustomerNumber();	

	}

	//@Daisy: Done!
	public void updateResponseValues() throws Exception {
		
		fetchallxmlTags(EopsresponseAsString, eopsresponse,"EopstoiBankingResponsePayload_Key","EopstoiBankingResponsePayload_Value");
	}

	//@Daisy: Done!
	public String verifyContentFromSoapXml(String xmlasString, String tagNametoVerify) throws Exception {

		try {
			List<String> output = getFullNameFromXml(xmlasString, tagNametoVerify);
			String[] strarray = new String[output.size()];
			output.toArray(strarray);
			String tagValue = removeOpenandClosebracket(Arrays.toString(strarray));
			return tagValue;

		} catch (Exception e) {
			return "mentionedtagnotavailable";
		}
	}

	//@Daisy : Done!
	public void verifyResponseCode() throws Exception {
		System.out.println("Response as String"+response.toString());
		//getFullNameFromXml(EopsresponseAsString, "middleName");
		int responseCode = response.getStatusCode();
		if (responseCode == 200) {
			StepDef.scenario.write("Response code Received------->"+responseCode);
			System.out.println("responseCode - " + responseCode);			

		} else {
			StepDef.scenario.write("Response code Received-------->"+responseCode);
			
		}

	}

	//@Daisy : Done!
	public String removeOpenandClosebracket(String inputString) {
		String output = inputString;
		output = output.replace("[", "");
		output = output.replace("]", "");
		return output;

	}

	//@Daisy : Done!
	public Document loadXMLString(String response) throws Exception {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(response));
		return db.parse(is);
	}

	//@Daisy : Check for duplicate function, else retain getfullnamefromxml
	public List<String> getFullNameFromXml(String response, String tagName) throws Exception {
		Document xmlDoc = loadXMLString(response);
		System.out.println("Get Full Name From XML" + xmlDoc.getNodeName().toString());
		NodeList nodeList = xmlDoc.getElementsByTagName(tagName);
		List<String> ids = new ArrayList<String>(nodeList.getLength());
		for (int i = 0; i < nodeList.getLength(); i++) {
			Node x = nodeList.item(i);
			System.out.println("Node Values------>" + x.getNodeName().toString());
			ids.add(x.getFirstChild().getNodeValue());

		}
		return ids;
	}

	//@Daisy : Excel printing can be included in this method
	public Map<String, String> selectValuesFromDB(String customerRefId) throws Exception {
		DataBaseConnectivity dbcon = new DataBaseConnectivity();
		Statement sqlstatement = dbcon.createConnection();
		Thread.sleep(10000);
		String readRecordSQL = "SELECT t.taskid,t.txrefno,t.statuscode,t.stepname,t.steplabel,t.selectedresponse,t.userresponse,t.responsecode,t.stepresponses,t.countrycode,t.processid,t.enqueuetime,t.locktime,t.modifiedtime,t.elapsedtime,t.lockeduser,t.channel,t.modifieduserid,t.queuename,t.scantime,t.isolatedregion,t.CATEGORY,t.laststepname,t.referrallist,t.seckey FROM eops_hub_rb_sit01.task t WHERE t.txrefno="
				+ "'" + customerRefId + "'" + "ORDER BY taskid DESC";
		System.out.println("DB connection Established: " + readRecordSQL);
		ResultSet myResultSet = sqlstatement.executeQuery(readRecordSQL);

		while (myResultSet.next()) {
			String stepName = myResultSet.getString("stepname");
			String stepresponse = myResultSet.getString("selectedresponse");
			System.out.println("stepName" + stepName + "and " + stepresponse);
			statusmap.put(stepName, stepresponse);
		}
		return statusmap;
	}

	
	
	//@Daisy: Assert's should work and still execution should continue
	public String verifyStatusCompleted(String status,String KeyValue) {
		String detailsToUpdate="";
		if (KeyValue.equalsIgnoreCase("Complete")) {
			 detailsToUpdate="<tr>"+"<td>"+status+"</td>"+"<td>"+KeyValue+"</td>"+"<td>Complete</td>"+"<td>Pass</td>"+"</tr>";
			reportlog("StatusNameFromDB", KeyValue, "Complete", "Pass");
			return detailsToUpdate;
		}  else 
		{
			 detailsToUpdate="<tr>"+"<td>"+status+"</td>"+"<td>"+KeyValue+"</td>"+"<td>Complete</td>"+"<td>Fail</td>"+"</tr>";
			reportlog("StatusNameFromDB", KeyValue, "Complete", "Fail");
			return detailsToUpdate;
		}
	}

	//@ulaganathan: newly added function
		public void verifyUP1ReqStatus(String KeyValue) {
			if (KeyValue.equalsIgnoreCase("UP1Req")) {
				reportlog("StatusNameFromDB", KeyValue, "UP1Req", "Pass");
			}  else 
			{
				reportlog("StatusNameFromDB", KeyValue, "UP1Req", "Fail");
			}
		}
		
		
		//@ulaganathan: newly added function
		public void verifySTPReqStatus(String KeyValue) {
			if (KeyValue.equalsIgnoreCase("STPReq")) {
				reportlog("StatusNameFromDB", KeyValue, "STPReq", "Pass");
			}  else 
			{
				reportlog("StatusNameFromDB", KeyValue, "STPReq", "Fail");
			}
		}
		
		
public void updatedExpectedTasklistValuesinMap(String excelKeyColumnName, String excelValueColumnName) throws FilloException
{
	Connection connection = fillo.getConnection(FileUtilities.inputExcelDetails);
	String strQuery = "Select * from "+ sheetName +" where TestCaseId='" + testcaseId + "'";
	System.out.println(strQuery);
	Recordset recordset = connection.executeQuery(strQuery);
	while (recordset.next()) {
		System.out.println("RecordKeyName in expectedStatus"+recordset.getField("Expected_WorkBaskets"));
		ArrayList<String> workBasket = splitTheInput(recordset.getField(excelKeyColumnName));
		ArrayList<String> workBasketStatus = splitTheInput(recordset.getField(excelValueColumnName));
		for (int i = 0; i < workBasket.size(); i++) {
			
			expectedTaskStatusDetails.put(workBasket.get(i), workBasketStatus.get(i));
			
		}
	}
	
	printMapValues(expectedTaskStatusDetails);
	
}
		
		
	//@Daisy : on fixing verifyStatusCompleted, commented lines to be enabled
	public void verifyCompleteStatus() throws Exception {
		updatedExpectedTasklistValuesinMap("Expected_WorkBaskets", "Expected_WB_taskStatus");
				try {
			selectValuesFromDB(customerReferenceNumber);
			System.out.println("Actual size------------>"+statusmap.size());
			System.out.println("Expected size---------->"+expectedTaskStatusDetails.size());
			int actual=statusmap.size();
			int expected=expectedTaskStatusDetails.size();
			for (int i = 0; i < 3; i++) {
				Thread.sleep(35000);
				if (actual>=expected) {
					System.out.println("30 sec completed..........");
				selectValuesFromDB(customerReferenceNumber);
				}
			}

			updatekeyMapValuesinExcelwithPipesymbol(statusmap, "Actual_WorkBaskets", "Actual_WB_taskStatus");
			verifyExpectedActualTaskName("Expected_Actual_WorkBaskets");
		//	verifyExpectedActualTaskStatus("Expected_Actual_WB_Status");
		//	printAllStatus(forAllstatusHtml);

		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			System.out.println("Null Pointer Exception");
		}
	}

	//@Daisy: All DB Methods to be contained in one method - with a case separation
	public void selectMessageFromDB(String MessageCode) throws Exception {

		DataBaseConnectivity dbcon = new DataBaseConnectivity();
		Statement sqlstatement = dbcon.createConnection();
		System.out.println("customerReferenceNumber" + customerReferenceNumber);

		String readRecordSQL = "select requestid,serviceid,messageid,requestmsg,responsemsg,sysmodifiedtime from EOPS_HUB_RB_SIT01.msgtxndetails where requestid="
				+ "'" + customerReferenceNumber + "'" + " and messageid=" + "'" + MessageCode + "'"
				+ "order by serviceid desc";

		System.out.println(readRecordSQL);
		ResultSet myResultSet = sqlstatement.executeQuery(readRecordSQL);
		while (myResultSet.next()) {
			if (MessageCode.equalsIgnoreCase("DLPK003")) {
				RequestSoapMessageInEOPS_HUB_RB_SIT01 = myResultSet.getString("requestmsg");
				System.out.println("Request Message--------------->>" + RequestSoapMessageInEOPS_HUB_RB_SIT01);
				ResponseSoapMessageInEOPS_HUB_RB_SIT01 = myResultSet.getString("responsemsg");
				System.out.println("Response------>" + ResponseSoapMessageInEOPS_HUB_RB_SIT01);
				updateStatusinExcel("DB_EOPStoICMPayload", RequestSoapMessageInEOPS_HUB_RB_SIT01);
				updateStatusinExcel("EopstoICMPayloadResponse", RequestSoapMessageInEOPS_HUB_RB_SIT01);

			} else if (MessageCode.equalsIgnoreCase("JMSDL_01")) {
				EopsToiBankingNotificationPayload = myResultSet.getString("requestmsg");
				updateStatusinExcel("EopsToiBankingNotificationPayload", EopsToiBankingNotificationPayload);
			}
		}
	}

	//@Daisy: Done!
	public void retrieveCustomerNumber() throws Exception {
		customerReferenceNumber = verifyContentFromSoapXml(EopsresponseAsString, "consumerRef");
		System.out.println(customerReferenceNumber);
	}

	//@Daisy : to be moved to Business Method
	public void verifySuccessMessage() throws Exception {
		String messageValue = verifyContentFromSoapXml(EopsresponseAsString, "message");
		if (messageValue.equalsIgnoreCase("Application Processed Successfully")) {
			
			StepDef.scenario.write("Response message Received------->"+messageValue);
			updateStatusinExcel("ResponseMessage", messageValue);	
		} else {
			StepDef.scenario.write("Response message Received------->"+messageValue);
			updateStatusinExcel("ResponseMessage", messageValue);	
		}
	}

	//@Daisy : to be moved to Business Method
	public void requestMessageFromDB() throws Exception {
		System.out.println("customerReferenceNumber -" + customerReferenceNumber);
		System.out.println("Request SOAP Message : " + RequestSoapMessageInEOPS_HUB_RB_SIT01);
		fetchallxmlTags(RequestSoapMessageInEOPS_HUB_RB_SIT01, EopstoICMPayload, "EopstoICMPayload_Key", "EopstoICMPayload_Value");
		
			}
	
	//@Daisy : To be moved to Business Method
	public void responseMessageFromDB() throws Exception {
		System.out.println("customerReferenceNumber -" + customerReferenceNumber);
		System.out.println(ResponseSoapMessageInEOPS_HUB_RB_SIT01);
		fetchallxmlTags(ResponseSoapMessageInEOPS_HUB_RB_SIT01, ICMtoEopsResponse, "ICMtoEopsRespPayload_Key", "ICMtoEopsRespPayload_Value");
	}

	//@Daisy : To be moved to Business Method
	public void NotifyMessageFromDB() throws Exception {
		System.out.println("Inside request message");
		System.out.println("customerReferenceNumber -" + customerReferenceNumber);
		System.out.println(RequestSoapMessageInEOPS_HUB_RB_SIT01);
		fetchallxmlTags(RequestSoapMessageInEOPS_HUB_RB_SIT01, RequestSoapMessageInEOPS, "EopsNotificationPayload_Key", "EopsNotificationPayload_Value");
	}

	//@Daisy: Sheet name to be dynamically addressed - Hardcoding to be removed
	public void updateStatusinExcel(String columnName, String valueToUpdate) throws FilloException {
		String strQuery;
		filloconnection = fillo.getConnection(FileUtilities.inputExcelDetails);
		if (!valueToUpdate.isEmpty()) {
			strQuery = "UPDATE "+sheetName+ " SET " + columnName + "='" + valueToUpdate + "' " + "where TestCaseId='"
					+ testcaseId + "'";
		} else {
			strQuery = "UPDATE "+sheetName+ " SET " + columnName + "=null" + "where TestCaseId='" + testcaseId + "'";
		}

		System.out.println("Query ---> " + strQuery);
		filloconnection.executeUpdate(strQuery);
		filloconnection.close();
	}


	
	
	
	//@Daisy : Please check to change all read to common method and all write to common method
	public Map<String, String> selectValueFromExcel(String excelKeyColumnName, String excelValueColumnName, String scenarioId)
			throws FilloException, ParserConfigurationException, SAXException, IOException, TransformerException {
		Fillo fillo = new Fillo();
		scenarioIdFromExcel = scenarioId;
		Map<String, String> mapForInput = new HashMap<String, String>();
		Connection connection = fillo.getConnection(FileUtilities.inputExcelDetails);
		String strQuery = "Select * from "+sheetName+ " where TestCaseId='" + testcaseId + "'";
		System.out.println(strQuery);
		Recordset recordset = connection.executeQuery(strQuery);
		while (recordset.next()) {
			System.out.println("RecordKeyName"+recordset.getField(excelKeyColumnName));
			ArrayList<String> tag = splitTheInput(recordset.getField(excelKeyColumnName));
			ArrayList<String> tagValue = splitTheInput(recordset.getField(excelValueColumnName));
			if (tag.size() == tagValue.size()) {
				for (int i = 0; i < tag.size(); i++) 
				{
					mapForInput.put(tag.get(i).toString(), tagValue.get(i).toString());
					update("pProcessServiceData", tag.get(i).toString(), tagValue.get(i).toString());
				}
			}

		}

		recordset.close();
		connection.close();
		return mapForInput;
	}

	//@Daisy : To be re-visited or removed
	public void update(String parentTagName, String TagName, String TagValue)
			throws ParserConfigurationException, SAXException, IOException, TransformerException {
		String filepath = FileUtilities.inputXmlPath;
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		Node parentNode = doc.getElementsByTagName(parentTagName).item(0);
		NodeList list = parentNode.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node node = list.item(i);
			// get the salary element, and update the value
			if (TagName.equals(node.getNodeName())) {
				node.setTextContent(TagValue);
			}
		}

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		transformer.transform(source, result);
		
		

	}

	//@Daisy : To be moved to common library / Utilities
	public  ArrayList<String> splitTheInput(String dataValue) {
		ArrayList<String> splitedValues = new ArrayList<String>();
		String[] valueFromExel = dataValue.split("\\|");
		for (String str : valueFromExel) {
			System.out.print(str);
			splitedValues.add(str);
		}
		return splitedValues;

	}

	//@Daisy : Done!
	public void fetchallxmlTags(String xmlasString,Map<String,String> mapName,String excelColumnNameforKey,String excelColumnNameforValue) throws Exception {

		InputStream inputStream = new ByteArrayInputStream(xmlasString.getBytes(Charset.forName("UTF-8")));
		XMLInputFactory inputFactory = XMLInputFactory.newFactory();
		XMLStreamReader reader = inputFactory.createXMLStreamReader(inputStream);
		inputFactory.setProperty(XMLInputFactory.IS_COALESCING, true);
		while (reader.hasNext()) {
			switch (reader.next()) {
			case XMLStreamConstants.START_ELEMENT:
				
				keyTag = reader.getName().toString();
				if (keyTag.startsWith("{")) {	
					keyTag=removeurlsFromTag(keyTag);
					
				}
				break;

			case XMLStreamConstants.END_ELEMENT:
				break;

			case XMLStreamConstants.CHARACTERS:
				
				
			case XMLStreamConstants.SPACE:
				keyTagValue = reader.getText().toString();
		
				if (!keyTagValue.trim().isEmpty()) {

					keyTagValue=removeAllspaceAndEmptyLines(keyTagValue);
					/*
					if(keyTag.equalsIgnoreCase("processdetails")&&keyTagValue.length()>1)
					{
						 putallxmltagsinMapandExcel(cDataDetails, keyTag, keyTagValue, "CDATAValue_Key", "CDATAValue_Value");
						 keyTagValue=keyTagValue.replaceAll(">]]", "");
						 
						 updateStatusinExcel("CDATAValue_Key",keyTag);
						 updateStatusinExcel("CDATAValue_Value",keyTagValue);
						 
					}
					*/
					
					 updatekeyValuesintoMap(mapName,keyTag,keyTagValue);
				}
				
				break;
				
			}
			
		}
		
		updatekeyMapValuesinExcelwithPipesymbol(mapName, excelColumnNameforKey, excelColumnNameforValue);
		 

	}
    
	//@Daisy : Done!
	public void updatekeyValuesintoMap(Map<String,String> mapName,String key, String value) throws Exception {	
		mapName.put(key, value);	
	}
	
	//@Daisy : Done!
	public void printMapValues(Map<String,String> mapName)
	{
		String key="";
		String value="";
		for (Map.Entry<String, String> entry : mapName.entrySet()) 
		{
			
			key=key+entry.getKey()+"|";
			value=value+entry.getValue()+"|";
			System.out.println("Values updated in Map Hello---->" + entry.getKey() + " : " + entry.getValue());
						
		}
		

	}


	
	
	public void updatekeyMapValuesinExcelwithPipesymbol(Map<String,String> mapName,String keyColumnName,String keyValueColumnName) throws FilloException
	{
		String keywithPipesymbol="";
		String valuewithPipesymbol="";
		for (Map.Entry<String, String> entry : mapName.entrySet()) 
		{
			keywithPipesymbol=keywithPipesymbol+entry.getKey()+"|";
			valuewithPipesymbol=valuewithPipesymbol+entry.getValue()+"|";				
						
		}

		updateStatusinExcel(keyColumnName, keywithPipesymbol);
		updateStatusinExcel(keyValueColumnName, valuewithPipesymbol);
	
	}

	
	public void verifyExpectedActualTaskName(String excelColmunName) throws FilloException
	{
		int expected=expectedTaskStatusDetails.size();
		int actual=statusmap.size();
		Map<String, String> actualExpectedMatched = new HashMap<>();
		Map<String, String> extraTaskDetailsfromDB = new HashMap<>();
		
		if (expected==actual) {
			if(statusmap.keySet().equals(expectedTaskStatusDetails.keySet())==true)
			{
				updateStatusinExcel(excelColmunName,"Pass");
				verifyExpectedActualTaskStatus(excelColmunName,statusmap,expectedTaskStatusDetails);
				
			}	
			else
			{
				updateStatusinExcel(excelColmunName,"Fail");
				updateStatusinExcel("DB_verification_Status_Comments","Expected workbasket values missing in the table, Please refer genie report");
				verifyExpectedActualTaskStatus(excelColmunName,statusmap,expectedTaskStatusDetails);

			}

		}
		
		else if(expected<actual)
		{
						
			for ( String key : statusmap.keySet()) {
			    String keyValueFromExpected=key;
			    if(expectedTaskStatusDetails.containsKey(keyValueFromExpected))
			    		{
			    	actualExpectedMatched.put(keyValueFromExpected, keyValueFromExpected);
			    	System.out.println("Temp size------->"+actualExpectedMatched.size());
			    		}
			    else
			    {
			    	extraTaskDetailsfromDB.put(keyValueFromExpected, keyValueFromExpected);
			    }
			    
			}
			
			verifyExpectedActualTaskStatus(excelColmunName, statusmap, actualExpectedMatched);	
			
		}
		
	
					
		else
		{
			updateStatusinExcel(excelColmunName,"Fail");
			updateStatusinExcel("DB_verification_Status_Comments","Expected workbasket values missing in the table, Please refer genie report");

		}	
			
	}
	
	
	public boolean verifyExpectedActualTaskStatus(String excelColmunName,Map<String,String> actual,Map<String,String> expected) throws FilloException
	{
	
			if(new ArrayList<>( actual.values() ).equals(new ArrayList<>( expected.values()))==true)
			{
				updateStatusinExcel(excelColmunName,"Pass");
				reportlogForMap(actual, expected, "Pass");
				return true;
				
			}	
		
		else
		{
			updateStatusinExcel(excelColmunName,"Fail");
			reportlogForMap(actual, expected, "Fail");
			return false;

		}
		
	}		
	
	public void reportlog(String Field,String ActualVal,String ExpectedVal,String status)
	
	       {
	              String htmlrep = 
	            		  	   "<html>" +
	            		  	   "<body>" +
	                           "<table border ='1'>" +
	                           "<tr>" +
	                           "<td>Field Name</td>" +
	                           "<td>Expected Result</td>" +
	                           "<td>Actual Result</td>" +
	                           "<td>Status</td>" +
	                           "</tr>"+
	                           "<tr>"+
	                           "<td>"+Field+"</td>"+
	                           "<td>"+ExpectedVal+"</td>"+
	                           "<td>"+ActualVal+"</td>"+
	                           "<td>"+status+"</td>"+
	                           "</tr>"+
	                           "</table>"+
	                           "</body>" +
	                           "</html>";              
	              StepDef.scenario.embed(htmlrep.getBytes(), "text/html");              
	       }
	
	
	
	public void reportlogForMap(Map<String,String> actualMap,Map<String,String> expectedMap,String status)
	
    {
         String output="";         
         String[] actualKey = actualMap.keySet().toArray(new String[0]);
         String[] actualValue=actualMap.values().toArray(new String[0]);
         String[] expectedValue=expectedMap.values().toArray(new String[0]);
		
         for (int i = 0; i < actualMap.size(); i++) {
        	 if(actualValue[i].equalsIgnoreCase(expectedValue[i]))
        	 {
        	 output=output+"<tr>"+"<td>"+actualKey[i]+"</td>" +"<td>"+actualValue[i]+"</td>" +"<td>"+expectedValue[i]+"</td>" +"<td> Pass </td></tr>";	
        	 }
        	 else
        	 {
        		 output=output+"<tr>"+"<td>"+actualKey[i]+"</td>" +"<td>"+actualValue[i]+"</td>" +"<td>"+expectedValue[i]+"</td>" +"<td> Fail </td></tr>";
        	 }
         }
         System.out.println("Output---"+output);
		
		String htmlrep = 
         		  	   "<html>" +
         		  	   "<body>" +
                        "<table border ='1'>" +
                        "<tr>" +
                        "<td>Field Name</td>" +
                        "<td>Expected Result</td>" +
                        "<td>Actual Result</td>" +
                        "<td>Status</td>" +
                        "</tr>"+
                        output+
                        "</table>"+
                        "</body>" +
                        "</html>";              
           StepDef.scenario.embed(htmlrep.getBytes(), "text/html");
           
    }
	
	
	
	public void printAllStatus(String outputValue)
	{
		String htmlrep = 
 		  	   "<html>" +
 		  	   "<body>" +
                "<table border ='1'>" +
                "<tr>" +
                "<td>Field Name</td>" +
                "<td>Expected Result</td>" +
                "<td>Actual Result</td>" +
                "<td>Status</td>" +
                "</tr>"+
                forAllstatusHtml+  
                "</table>"+
                "</body>" +
                "</html>";              
   StepDef.scenario.embed(htmlrep.getBytes(), "text/html");              
	
	}

	public String fileToString(String filepath) throws FileNotFoundException
	{
	       try
	       {
	       InputStream input = new FileInputStream(filepath);
	              int size = input.available();
	              byte[] buffer = new byte[size];
	              input.read(buffer);
	              String text = new String(buffer);
	              input.close();
	              return text;
	       }
	       catch(IOException e)
	       {
	              e.printStackTrace();
	              return "pleaseEnterValidFilePath";
	       }
	       
	         
	 }

	public void updateCDataValue(String cDataparentTagName)
			throws ParserConfigurationException, SAXException, IOException, TransformerException {
		String filepath = FileUtilities.inputXmlPath;
		String xmlPayloadAsString=fileToString(filepath);
		String xmlWithoutCDATAtag=removeCDataTags(xmlPayloadAsString);
		System.out.println("Without CData------------->"+xmlWithoutCDATAtag);
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(xmlWithoutCDATAtag));
		Document doc = docBuilder.parse(is);
		Node parentNode = doc.getElementsByTagName(cDataparentTagName).item(0);
		NodeList list = parentNode.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node node = list.item(i);
			for (Map.Entry<String, String> entry : cdataInputasMap.entrySet()) 
			{
					if (entry.getKey().equals(node.getNodeName())) {	
					node.setTextContent(entry.getValue());					
				}		
							
			}

					}

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		transformer.transform(source, result);
		String outputs=fileToString(filepath);
		String withCDataValue=addCDataTags(outputs);
			writeStringasxml(FileUtilities.inputXmlPath, withCDataValue);
		System.out.println(withCDataValue); //empty tags should not end with single param tag
	
	}


public String removeCDataTags(String payloadData)
{
	String outputValue=payloadData;
	outputValue=outputValue.replaceAll("<!\\[CDATA\\[", "");
	outputValue=outputValue.replaceAll("]]]]>>]]>", "");
	outputValue=outputValue.replaceAll("]]>", "");
	outputValue= outputValue.replaceAll("&lt;", "<");
	outputValue=outputValue.replaceAll("&gt;", ">");
	outputValue=outputValue.replaceAll(">>>", "");
	outputValue=outputValue.replaceAll("]]", "");
	return outputValue;
	

}

//@Daisy: Hardcoding of Processdetails to be removed
public String addCDataTags(String payloadData)
{
	String updateCdataTag=payloadData;
	updateCdataTag=updateCdataTag.replaceAll("<processdetails>", "<processdetails>\n<![CDATA[");
	updateCdataTag=updateCdataTag.replaceAll("</processdetails>", "]]]]>><![CDATA[]]></processdetails>");
	updateCdataTag= updateCdataTag.replaceAll("&lt;", "<");
	updateCdataTag=updateCdataTag.replaceAll("&gt;", ">");
	updateCdataTag=updateCdataTag.replaceAll("&gt;", ">");
	updateCdataTag=updateCdataTag.replaceAll("[\\\r\\\n]+","");
	System.out.println("With CData------------->"+updateCdataTag);
	return updateCdataTag;
}	

public void writeStringasxml(String filePath,String stringTobeAdded)
{	
	try
    {
    File outputXmlFile = new File(filePath);
           FileWriter fw= new FileWriter(outputXmlFile);
           fw.write(stringTobeAdded);
           fw.flush();
           fw.close();
    }
    catch(IOException e)
    {
           e.printStackTrace();
           
    }

	
}

public void replaceEncodingChar(String inputForreplace)
{
	String replaceEncoding=inputForreplace;
	replaceEncoding= replaceEncoding.replaceAll("&lt;", "<");
	replaceEncoding=replaceEncoding.replaceAll("&gt;", ">");
	   
}

public void updateCDataValueinExcel(String cDataParentTag) throws Exception
{
	
	String filepath = FileUtilities.inputXmlPath;
	String xmlPayloadAsString=fileToString(filepath);
	updatecDataValueinMapandExcel(xmlPayloadAsString, cdataInputasMap, "CDATAValue_Key", "CDATAValue_Value");
}




public void fetchTheValueFromExcel(String parentTagName,String excelKeyColumnName,String excelValueColumnName,String scenarioId) throws ParserConfigurationException, SAXException, IOException, TransformerException, FilloException
{
	Connection connection = fillo.getConnection(FileUtilities.inputExcelDetails);
	String strQuery = "Select * from "+sheetName+ " where TestCaseId='" + testcaseId + "'";
	System.out.println(strQuery);
	Recordset recordset = connection.executeQuery(strQuery);
	while (recordset.next()) {
		
		System.out.println("RecordKeyName"+recordset.getField(excelKeyColumnName));
		ArrayList<String> tag = splitTheInput(recordset.getField(excelKeyColumnName));
		ArrayList<String> tagValue = splitTheInput(recordset.getField(excelValueColumnName));
		if (tag.size() == tagValue.size()) {
			for (int i = 0; i < tag.size(); i++) 
			{
				updateCDataValue(parentTagName);
			}
		}

	}

	recordset.close();
	connection.close();

}




public Map<String, String> splitAndStoreValueFromexcelToMap(String excelKeyColumnName,String excelValueColumnName) throws FilloException
{
	Connection connection = fillo.getConnection(FileUtilities.inputExcelDetails);
	String strQuery = "Select * from "+sheetName+" where TestCaseId='" + testcaseId + "'";
	System.out.println(strQuery);
	Recordset recordset = connection.executeQuery(strQuery);
	while (recordset.next()) {
		
		
		ArrayList<String> tag = splitTheInput(recordset.getField(excelKeyColumnName));
		ArrayList<String> tagValue = splitTheInput(recordset.getField(excelValueColumnName));
		if (tag.size() == tagValue.size()) {
			for (int i = 0; i < tag.size(); i++) 
			{
				cdataInputasMap.put(tag.get(i),tagValue.get(i));
			}
		}

	}

	recordset.close();
	connection.close();
return cdataInputasMap;
}

public String removeurlsFromTag(String tagName)
{
	String newText = tagName.replaceAll("(\\{https?|ftp|file)://[-a-zA-Z0-9+&@#/%?=~_|!:,.;]*[-a-zA-Z0-9+&@#/%=~_|]", "");
	newText=newText.replaceAll("[{}]", "");
	return newText;
}

public String removeAllspaceAndEmptyLines(String stringName)
{
	String inputString = stringName.replaceAll("[\\\r\\\n]+", "");
	inputString = inputString.replaceAll("\\s", "");
	return inputString;
	
}


public void updatecDataValueinMapandExcel(String xmlasString,Map<String,String> mapName,String excelColumnNameforKey,String excelColumnNameforValue) throws Exception {

	InputStream inputStream = new ByteArrayInputStream(xmlasString.getBytes(Charset.forName("UTF-8")));
	XMLInputFactory inputFactory = XMLInputFactory.newFactory();
	XMLStreamReader reader = inputFactory.createXMLStreamReader(inputStream);
	inputFactory.setProperty(XMLInputFactory.IS_COALESCING, true);
	while (reader.hasNext()) {
		switch (reader.next()) {
		case XMLStreamConstants.START_ELEMENT:
			
			keyTag = reader.getName().toString();
			break;

		case XMLStreamConstants.END_ELEMENT:
			break;

		case XMLStreamConstants.CHARACTERS:
				
		case XMLStreamConstants.SPACE:
			keyTagValue = reader.getText().toString();
	
			if (!keyTagValue.trim().isEmpty()) {

				keyTagValue=removeAllspaceAndEmptyLines(keyTagValue);
				
				if(keyTag.equalsIgnoreCase("processdetails")&&keyTagValue.length()>1)
				{
					
					 keyTagValue=keyTagValue.replaceAll(">]]", "");					 
					 updateStatusinExcel(excelColumnNameforKey,keyTag);
					 updateStatusinExcel(excelColumnNameforValue,keyTagValue);
					 
				}
				
			}
			
			break;
			
		}
		
	}		 
}




}



