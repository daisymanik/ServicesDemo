package com.scb.module.collection_cib;



import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.NamespaceContext;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.google.common.base.Utf8;
import com.scb.module.collection_cib_Utility.FileUtilities;
import com.scb.module.collection_cib_Utility.SoapXMLParser;

public class WritePayLoad {
	static SoapXMLParser soapCheck=new SoapXMLParser();
	static String dataValue="";
	static String countryValue="PK";
	static String messageId="INITPROC";
	static String stp="STP";
	static String sourcereferenceNo="PK8925161922M864935161932M86480";
	static String sourceShortRefNo="PK8925161932M86480STP";
	static String addlStatus="N";
	static String clientId="IBNK";
	static String profileId="5860000001106140";
	static FileWriter foutput;
	 Map<String, String> tagmap=new HashMap<>();
	 String keyTag="";
	 String keyTagValue="";
	 String cDataTags="";
	 static String cDataAsString="";
	 static String cDataAfterUpdate="";
	 

	public static void main(String[] args) throws FilloException, IOException, ParserConfigurationException, SAXException, TransformerException, XMLStreamException {
		// TODO Auto-generated method stub
	//	WritePayLoad.getTheValuesFromDataBase();
	//	WritePayLoad.WriteToPayLoadValues();
			
//		WritePayLoad.againChecking();
		//System.out.println("Cdata in main function"+cDataAsString);
	//update(cDataAsString, "customerDetails", "qualification", "DIP1");
//	System.out.println("cDataAfterUpdate"+cDataAfterUpdate);
	//	WritePayLoad.finalTry(cDataAfterUpdate);
		WritePayLoad.updateFinal("customerDetails", "firstName", "Srikela");
//	WritePayLoad payload=new WritePayLoad();
	
	
	
	}

	public static String getTheValuesFromDataBase() throws FilloException
	{
		
		Fillo fillo=new Fillo();
		Connection connection=fillo.getConnection("C:\\Users\\1601017\\Desktop\\TestData.xlsx");
		 String strQuery="Select * from TestData where ProfileId='"+profileId+"'";
		    Recordset recordset=connection.executeQuery(strQuery);

		    while(recordset.next()){
		        ArrayList<String> dataColl=recordset.getFieldNames();
		        System.out.println(dataColl);
		        Iterator<String> dataIterator=dataColl.iterator();
		        System.out.println(dataColl.size());  	        
		        while(dataIterator.hasNext()){
	                for (int i=0;i<=dataColl.size()-1;i++){
	                    //System.out.println(i);
	                    String data=dataIterator.next();
	                    dataValue=dataValue+recordset.getField(data)+"|";
		    }
		        }
		    }
		    connection.close();
			return dataValue;	
	}
	
	
	public static String[] splitTheInput()
	{
		System.out.println(dataValue);
		String[] valueFromExel=dataValue.split("\\|");
		return valueFromExel;
		
	}

	public static void  WriteToPayLoadValues() throws FilloException, IOException
	{
	//	String valueBeforeSplit=WritePayLoad.getTheValuesFromDataBase();
		String[] valueAfterSplit=WritePayLoad.splitTheInput();
		String str="<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"
				+"<soapenv:Body>"
				+"<ns2:service xmlns:ns2=\"http://processorigination.intface.eops/\">"
				+"<pProcessServiceData>"
				+"<country>" + countryValue +"</country>"
				+"<messageId>" + messageId +"</messageId>"
				+"<requestType>"+stp+"</requestType>"
				+"<sourceRefNo>"+sourcereferenceNo+"</sourceRefNo>"
				+"<sourceShortRefNo>"+sourceShortRefNo+"</sourceShortRefNo>"
				+"<addlStatus>"+addlStatus+"</addlStatus>"
				+"<clientId>"+clientId+"</clientId>"
				+"<processData>"
				+"<processdetails>"
				+"<![CDATA[<customerDetails>"
				+"<relationshipNo>"+valueAfterSplit[0]+"</relationshipNo>"
				+"<firstName>"+valueAfterSplit[1]+"</firstName>"
				+"<middleName>"+valueAfterSplit[2]+"</middleName>"
				+"<lastName>"+valueAfterSplit[3]+"<lastName>"
				+"<gender>"+valueAfterSplit[4]+"</gender>"
				+"<lastReviewDate>"+valueAfterSplit[5]+"</lastReviewDate>"
				+"<ProfileId>"+valueAfterSplit[6]+"</ProfileId>"
				+"<OperationMode>"+valueAfterSplit[7]+"</OperationMode>"
				+"<custInfoAddressDetails>"
				+"<addressDetails>"
				+"<addressType>"+valueAfterSplit[8]+"</addressType>"
				+"<addressLine1>"+valueAfterSplit[9]+"</addressLine1>"
				+"<addressLine2>"+valueAfterSplit[10]+"</addressLine2>"
				+"<streetName>"+valueAfterSplit[11]+"</streetName>"
				+"<cityCode>"+valueAfterSplit[12]+"</cityCode>"
				+"<state>"+valueAfterSplit[13]+"</state>"
				+"<countryCode>"+valueAfterSplit[14]+"</countryCode>"
				+"<nearestLandmark>"+valueAfterSplit[15]+"</nearestLandmark>"
				+"<postalCode>"+valueAfterSplit[16]+"</postalCode>"
				+"<postBox>"+valueAfterSplit[17]+"</postBox>"
				+"<cityName>"+valueAfterSplit[18]+"</cityName>"
				+"<isMailingAddress>"+valueAfterSplit[19]+"</isMailingAddress>"
				+"<operationMode>"+valueAfterSplit[20]+"</operationMode>"
				+"</addressDetails>"
				+"</custInfoAddressDetails>"
				+"</customerDetails>]]]]>><![CDATA[]]></processdetails>"
				+"</processData>"
				+"<requestdatetime>2019-05-16 19:24:00</requestdatetime>"
				+"</pProcessServiceData>"
				+"</ns2:service>"
				+"</soapenv:Body>"
				+"</soapenv:Envelope>";
		System.out.println(str);
		foutput=new FileWriter("C:\\Users\\1601017\\Desktop\\RestAPI\\STP Request and Response XML Files\\FromIBankingToEops\\iBankingToEops.xml");
		foutput.write(str);
		foutput.close();		
	}
	
	public static void update() throws ParserConfigurationException, SAXException, IOException, TransformerException
	{

      
		String filepath = "C:\\Users\\1601017\\genie-projects\\sample\\src\\test\\resources\\InputDetails\\iBankingToEops.xml";
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		System.out.println("String xml file"+doc.toString());
		//Node staff = doc.getElementsByTagName("processdetails").item(0);
		NodeList list = doc.getChildNodes();
		List<String> ids = new ArrayList<String>(list.getLength());
		for (int i = 0; i < list.getLength(); i++) {
			System.out.println("length--------->"+list.getLength());
                   Node node = list.item(i);
                   
System.out.println("Node Name"+node.getNodeName());
		   // get the salary element, and update the value
		   if ("firstName".equals(node.getNodeName())) {
			node.setTextContent("ULAGS");
		   }

            
	}
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		transformer.transform(source, result);

	}

	
	public static void updatevalue() throws ParserConfigurationException, SAXException, IOException, TransformerException
	{

      
		String filepath = "C:\\Users\\1601017\\genie-projects\\sample\\src\\test\\resources\\InputDetails\\iBankingToEops.xml";
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(filepath);
		//doc.getChildNodes()
		System.out.println("String xml file"+doc.toString());
		Node nodeCdata;
		Short sdsd=Node.CDATA_SECTION_NODE;
		System.out.println(sdsd.toString());
		Node staff = doc.getElementsByTagName("processdetails").item(0);
		NodeList list = staff.getChildNodes();
		List<String> ids = new ArrayList<String>(list.getLength());
		for (int i = 0; i < list.getLength(); i++) {
			
                   Node node = list.item(i);
                   Short dss=Node.CDATA_SECTION_NODE;
                   System.out.println(dss.toString());
                	   
                   System.out.println("Node Name"+node.getNodeName());
		   // get the salary element, and update the value
		   if ("customerDetails".equals(node.getNodeName())) {
			node.setTextContent("ULAGS");
		   }

            
	}
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		transformer.transform(source, result);

	}

	public  void fetchallxmlTags(String xmlasString) throws FileNotFoundException, XMLStreamException
	{
		
		InputStream inputStream = new ByteArrayInputStream(xmlasString.getBytes(Charset.forName("UTF-8")));
		InputStream stream=new FileInputStream("C:\\Users\\1601017\\genie-projects\\sample\\src\\test\\resources\\InputDetails\\iBankingToEops.xml");
		XMLInputFactory inputFactory=XMLInputFactory.newFactory();
		XMLStreamReader reader=inputFactory.createXMLStreamReader(stream);
		inputFactory.setProperty(XMLInputFactory.IS_COALESCING, true);
		while(reader.hasNext())
		{
			switch(reader.next())
			{
			case XMLStreamConstants.START_ELEMENT:
				keyTag=reader.getName().toString();
				break;
				
			case XMLStreamConstants.END_ELEMENT:
				break;
				
			case XMLStreamConstants.CHARACTERS:
			case XMLStreamConstants.SPACE:
				keyTagValue=reader.getText().toString();
				if(!keyTagValue.trim().isEmpty())
				{
					
					keyTagValue=keyTagValue.replaceAll("[\\\r\\\n]+","");
					keyTagValue=keyTagValue.replaceAll("\\s","");
					putallxmltagsinMapandExcel(keyTag,keyTagValue);
						
				
					
				}
						break;
			}
			
				
		}
		
		
	}
	
	
	
	public void putallxmltagsinMapandExcel(String Key,String value)
	{
		Map<String, String> maptest=new HashMap<>();
		maptest.put(Key, value);
		for (Map.Entry<String, String> entry : maptest.entrySet()) {
		    System.out.println("Map2 ------->"+entry.getKey()+" : "+entry.getValue());
		    
				}
		
		
	}
	
	public static void againChecking() throws XMLStreamException, IOException, ParserConfigurationException, SAXException, TransformerException
	{
		String keyTag="";
		String keyTagValue="";
		InputStream inputStream = new FileInputStream(new File("C:\\Users\\1601017\\genie-projects\\sample\\src\\test\\resources\\InputDetails\\iBankingToEops.xml"));
		XMLInputFactory inputFactory = XMLInputFactory.newFactory();
		XMLStreamReader reader = inputFactory.createXMLStreamReader(inputStream);
		inputFactory.setProperty(XMLInputFactory.IS_COALESCING, true);
				while(reader.hasNext())
		{
			switch(reader.next())
			{
						case XMLStreamConstants.START_ELEMENT:
				keyTag=reader.getName().toString();
				
				break;
				
			case XMLStreamConstants.END_ELEMENT:
				
				break;
				
				
			case XMLStreamConstants.CHARACTERS:
			case XMLStreamConstants.SPACE:
				keyTagValue=reader.getText().toString();
				if(!keyTagValue.trim().isEmpty()&&keyTag.equalsIgnoreCase("processdetails")&&keyTagValue.length()>1)
				{
					keyTagValue=keyTagValue.replaceAll("[\\\r\\\n]+","");
					keyTagValue=keyTagValue.replaceAll("\\s","");
					keyTagValue=keyTagValue.replaceAll("]]", "");
					System.out.println(keyTag);
					System.out.println(keyTagValue);	
					cDataAsString=keyTagValue;
				
					
					
					/*
					XMLOutputFactory f = XMLOutputFactory.newInstance();					
					XMLStreamWriter writer=f.createXMLStreamWriter(new FileOutputStream("C:\\Users\\1601017\\genie-projects\\sample\\src\\test\\resources\\InputDetails\\iBankingToEops.xml"),"UTF-8");
					writer.writeCharacters("Hello");
					writer.flush();
					 writer.close();
					*/
				
					
						
				
					
				}
				
				else
				{
					
				}
						break;
						
			}
			
				
	
		}
				

	}
	
	
	public static void finalTry(String writeinCData) throws XMLStreamException, IOException, ParserConfigurationException, SAXException
	{
		 XMLInputFactory inFactory = XMLInputFactory.newInstance();
		 InputStream inputStream = new ByteArrayInputStream(cDataAsString.getBytes(Charset.forName("UTF-8")));
		    XMLEventReader eventReader = inFactory.createXMLEventReader(inputStream);
		    XMLOutputFactory factory = XMLOutputFactory.newInstance();
		    OutputStream out = new FileOutputStream(new File("C:\\Users\\1601017\\Desktop\\file.xml"));
		    XMLEventWriter writer = factory.createXMLEventWriter(out,"UTF-8");
		    XMLEventFactory eventFactory = XMLEventFactory.newInstance();
		    String tagName="";
		    while (eventReader.hasNext()) {
		        XMLEvent event = eventReader.nextEvent();
		        writer.add(event);
		        
		        
		        if (event.getEventType() == XMLEvent.START_ELEMENT) 
		        {
		        	tagName=event.asStartElement().getName().toString();
		            if (tagName.equalsIgnoreCase("qualification")) 
		            {	
		            	System.out.println("In if loop");
		            	
		            	 System.out.println("Write in cdata here"+writeinCData);
		            	writer.add(eventFactory.createCharacters(writeinCData));
		            	
		               
		            }
		            else
		            {
		            	System.out.println("In else loop");
		            }
		        }
		        
		        
		    	
		     		         }
		    
		   
		    writer.close();
		    String outputs=FileUtils.readFileToString(new File("C:\\Users\\1601017\\Desktop\\file.xml"));
		   outputs= outputs.replaceAll("&lt;", "<");
		   outputs=outputs.replaceAll("&gt;", ">");
		   outputs=outputs.replaceAll("<customerDetails>", "<![CDATA[<customerDetails>");
		   outputs=outputs.replaceAll("</customerDetails>]]", "</customerDetails>]]]]>><![CDATA[]]>");
		   System.out.println(outputs);
		    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			Document doc = docBuilder.parse("C:\\Users\\1601017\\Desktop\\file.xml");
			System.out.println("String xml file"+doc.toString());
		    
			
	}
	
	public static void replace()
	{
		
	}
	
	
	public static void updateInXml() throws XMLStreamException, IOException
	{
		String keyTag="";
		InputStream inputStream = new FileInputStream("C:\\Users\\1601017\\genie-projects\\sample\\src\\test\\resources\\InputDetails\\iBankingToEops.xml");
		XMLInputFactory inputFactory = XMLInputFactory.newFactory();
		XMLStreamReader reader = inputFactory.createXMLStreamReader(inputStream);
		XMLOutputFactory f = XMLOutputFactory.newInstance();
		XMLStreamWriter writer = f.createXMLStreamWriter(new FileOutputStream("C:\\Users\\1601017\\genie-projects\\sample\\src\\test\\resources\\InputDetails\\iBankingToEops.xml"));
		while (reader.hasNext()) {
			switch (reader.next()) {
			case XMLStreamConstants.START_ELEMENT:
				 keyTag = reader.getName().toString();
				break;
			case XMLStreamConstants.SPACE:
				if(keyTag.equalsIgnoreCase("country"))
				{
					inputStream.close();
					writer.writeCharacters("Hello");
						
				}				
					
			}
			
			}

		 writer.flush();
		 writer.close();

	}

	
	public static void update(String xmlasString,String parentTagName, String TagName, String TagValue)
			throws ParserConfigurationException, SAXException, IOException, TransformerException {
		InputStream inputStream = new ByteArrayInputStream(xmlasString.getBytes(Charset.forName("UTF-8")));	
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		Document doc = docBuilder.parse(inputStream);
		NodeList nodename=doc.getElementsByTagName(TagName);
		System.out.println("Testing         -------------"+nodename.toString());
		Node parentNode = doc.getElementsByTagName(parentTagName).item(0);
		NodeList list = parentNode.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node node = list.item(i);
			
			// get the salary element, and update the value
			if (TagName.equals(node.getNodeName())) {
				System.out.println("In If loop"+node.getNodeName());
				node.setTextContent("Hello");
				
			}
			else
			{
				System.out.println("In else loop"+node.getNodeName());
			}
		}

		/*
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StringWriter outWriter = new StringWriter();
		StreamResult result = new StreamResult(outWriter);
		transformer.transform(source, result);
		StringBuffer sb = outWriter.getBuffer();
		String finalstring = sb.toString();
System.out.println("Final string"+finalstring);
*/
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(FileUtilities.inputXmlPath));
		transformer.transform(source, result);


	}
		
	public static void updateFinal(String parentTagName, String TagName, String TagValue)
			throws ParserConfigurationException, SAXException, IOException, TransformerException {
		String filepath = FileUtilities.inputXmlPath;
		String inputString=FileUtils.readFileToString(new File(filepath));
		inputString=inputString.replaceAll("<!\\[CDATA\\[", "");
		inputString=inputString.replaceAll("]]]]>>", "");
		inputString=inputString.replaceAll("]]>", "");
		inputString= inputString.replaceAll("&lt;", "<");
		inputString=inputString.replaceAll("&gt;", ">");
		inputString=inputString.replaceAll(">>>", "");
		System.out.println("Input String"+inputString);
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		InputSource is = new InputSource(new StringReader(inputString));
		Document doc = docBuilder.parse(is);
		Node parentNode = doc.getElementsByTagName(parentTagName).item(0);
		NodeList list = parentNode.getChildNodes();
		for (int i = 0; i < list.getLength(); i++) {
			Node node = list.item(i);
			// get the salary element, and update the value
			if (TagName.equals(node.getNodeName())) {
				node.setTextContent(TagValue);
			}
		}

		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(filepath));
		transformer.transform(source, result);
		String outputs=FileUtils.readFileToString(new File(filepath));
		outputs=outputs.replaceAll("<processdetails>", "<processdetails>\n<![CDATA[");
		outputs=outputs.replaceAll("</processdetails>", "]]]]>><![CDATA[]]></processdetails>");
		FileUtils.writeStringToFile(new File(filepath), outputs);

System.out.println(outputs);
	}
	
}


