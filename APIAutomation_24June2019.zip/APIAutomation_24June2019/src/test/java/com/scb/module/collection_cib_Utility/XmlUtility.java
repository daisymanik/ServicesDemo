package com.scb.module.collection_cib_Utility;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.dom4j.io.SAXReader;
import org.w3c.dom.Document;
import org.w3c.dom.Node;


public class XmlUtility {

//XML creation for FPS 
	public void xmlCreationAcceptance(HashMap<String, String> xmlChange, String attrValue,String fileName) throws Exception{
		DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
		f.setNamespaceAware(true);
		DocumentBuilder b = f.newDocumentBuilder();
		Document doc = b.parse(new File(System.getProperty("user.dir") + "/src/test/resources/"+fileName+".xml"));
		XPath xPath = XPathFactory.newInstance().newXPath();
		xPath.setNamespaceContext(new NamespaceContext() {
			public String getNamespaceURI(String prefix) {
				String retStr = "";
				if(prefix.equals("fps")){
					retStr = "urn:hkicl:fps:xsd:fps.envelope.01";
				}
				else if(prefix.equals("ah")){
					retStr = "urn:iso:std:iso:20022:tech:xsd:head.001.001.01";
				}
				else if(prefix.equals("doc")){
					retStr = "urn:iso:std:iso:20022:tech:xsd:pain.012.001.05";
				}
				return retStr;
			}

			public Iterator<?> getPrefixes(String val) {
				return null;
			}

			public String getPrefix(String uri) {
				return null;
			}
		});
		for (String key : xmlChange.keySet()) {
			Node startDateNode = (Node) xPath.compile(key).evaluate(doc, XPathConstants.NODE);
			startDateNode.setTextContent(xmlChange.get(key));
		}
		
		Node currencyNode = (Node) xPath.compile("//doc:MaxAmt").evaluate(doc, XPathConstants.NODE);
		currencyNode.getAttributes().getNamedItem("Ccy").setNodeValue(attrValue);;
		
		
		Transformer tf = TransformerFactory.newInstance().newTransformer();
		tf.setOutputProperty(OutputKeys.INDENT, "yes");
		tf.setOutputProperty(OutputKeys.METHOD, "xml");
		tf.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");

		DOMSource domSource = new DOMSource(doc);
		StreamResult sr = new StreamResult(new File(System.getProperty("user.dir") + "/src/test/resources/"+fileName+".xml"));
		tf.transform(domSource, sr);
	}
	
	public void save_stageXML(String path, String flName) throws Exception{
		CommonUtils commonutil = new CommonUtils();
		String cont = commonutil.getLog_Server(path,flName);
		FileWriter file = new FileWriter(System.getProperty("user.dir") + "/src/test/resources/EDDAStage.xml");
		BufferedWriter bw = new BufferedWriter(file);
		bw.write(cont);
		bw.flush();
		bw.close();
	}
	
	public String getContent_XML(String xpath) throws Exception{
		SAXReader saxReader = new SAXReader();
		File file1 = new File(System.getProperty("user.dir") + "/src/test/resources/EDDAStage.xml");
		org.dom4j.Document document = saxReader.read(file1); 	
        return (document.selectSingleNode(xpath).getText());
	}
}
