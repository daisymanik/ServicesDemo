package com.scb.module.collection_cib_Utility;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.jcraft.jsch.Logger;

public class Field_Validation {


	DataProvider data = new DataProvider();
	CommonUtils common = new CommonUtils();
	
	// Validating the API response fields. If any new field comes in the response or any field missed in the response the function will assert it.
	

	public  void ddi_Validation(HashMap<Object,Object> hm,DataProvider dataProvider, String testCaseID, String sheetName,String Columnname) throws Exception
	{


		String Fields[] =  common.extractfields(dataProvider, testCaseID, sheetName, Columnname);
		for (String Fildscheck:Fields)

		{
			if(hm.containsKey(Fildscheck))
			{

				Assert.assertTrue(true);
			}	

			else
			{
				if(Fildscheck.equals("Optional1")||Fildscheck.equals("Optional2"))
				{
					Assert.assertTrue(true);
				}
				else{
				System.out.println("Field is not coming in response - "+Fildscheck);
				Assert.assertTrue(false);
				}}}	





		//Check String  contains in MAP Keyvalue

		for(Map.Entry key:hm.entrySet())
		{
			boolean flag=false;
			String Fildscheck="";
			String keyval= (String) key.getKey();

			for(int i=0;i<Fields.length;i++)
			{	
				Fildscheck = Fields[i];
				if(keyval.equals(Fildscheck))  
				{
					flag=true;

					Assert.assertTrue(true);
					break;
				}

			}

			if(flag==false)
			{
				if(Fildscheck.equals("Optional1")||Fildscheck.equals("Optional2"))
				{
					Assert.assertTrue(true);
				}
				else{
					System.out.println("Extera field is coming  respone - "+" "+ keyval);
					Assert.assertTrue("Extera field is coming  respone - "+" "+ keyval,false);
				}
			}

		}



	}
}