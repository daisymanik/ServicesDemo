/* Comments */

package com.scb.module.collection_cib;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.xml.sax.SAXException;
import com.codoid.products.exception.FilloException;

import com.scb.module.collection_cib_Utility.SoapXMLParser;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.And;






public class StepDef {
	SoapXMLParser soapXml=new SoapXMLParser();
	public static Scenario scenario;

	
	@Before
	public void before(Scenario scenario) throws Exception {
		StepDef.scenario = scenario;
		System.out.println("In Before");

	}

	
	
	@When("I do the deed")
	public void do_the_deed() {
	    System.out.println("This goes to STDOUT, but not into the report");
	}

	@Given("^Rest EDDA S2BAPI EndPoint$")
	public void endPoint()
	
	{
		
		scenario.write("This goes into the report");	
	    System.out.println("In Rest EDDA S2BAPI EndPoint");
		soapXml.baseUrlDetails();		
	}
	

	
	@Given("^input payload has the profile update details appended based on \"([^\"]*)\" sheet \"([^\"]*)\"$")
	public void verifyInputPayload(String testScenarioId,String testSheetName) throws Exception
	{
		
		System.out.println("input payload has the profile update details appended");
		
		soapXml.testcaseId=testScenarioId;
		soapXml.sheetName=testSheetName;
		soapXml.splitAndStoreValueFromexcelToMap("CDATAInput_Key","CDATAInput_Value");
		soapXml.updateCDataValue("customerDetails");
		soapXml.updateCDataValue("pProcessServiceData");
		soapXml.updateCDataValueinExcel("customerDetails");
		//soapXml.selectValueFromExcel("CDATAValue_Key","CDATAValue_Value","TC_01");
	}
	
	@When("^the iBanking request is sent, eops response is received$")
	public void storetheResponse() throws Exception
	{
		System.out.println("the iBanking request is sent, eops response is received");
		soapXml.updateThePayloadValues();
	}
	
	@And("^verify Eops response status code is 200$")
	public void  verifyResponseCode() throws Exception
	{
		System.out.println("verify Eops response status code is 200");
		soapXml.verifyResponseCode();
		
	}
	
	
	@And("^verify Eops response message is Application Processed Successfully$")
	public void verifySuccessMessage() throws Exception
	{
		
		soapXml.verifySuccessMessage();
		
		
		
	}
	

	@And("^verify AR_ContentUpdater,AR_CloseFTD,AR_UP4,AR_UP3,AR_UP2,AR_UP1,AR_WFLaunch,DATALOCKERWF status is completed in eops_hub_rb_sit01 table$")
	public void verifyStatusMessage() throws Exception
	{
		soapXml.verifyCompleteStatus();
		soapXml.updateResponseValues();
		
	}
	
	
	@And("^verify Request SOAP Message in EOPS_HUB_RB_SIT01 table$")
	public void verifyRequestSOAPMessage() throws Exception
	{
		soapXml.selectMessageFromDB("DLPK003"); //Please remove hard coding
		soapXml.selectMessageFromDB("JMSDL_01");
		soapXml.requestMessageFromDB();
		
	}
	
	
	@And("^verify Response SOAP Message in EOPS_HUB_RB_SIT01 table$")
	public void verifyReponseSOAPMessage() throws Exception
	{
		soapXml.responseMessageFromDB();
	}
	
	@And("^verify Notification Message in EOPS_HUB_RB_SIT01 table$")
	public void verifyNotification() throws Exception
	{
		soapXml.NotifyMessageFromDB();
	}
	
	
	@And("^verify the data in ICM table for value update$")
	public void verifydatainICM()
	{
		System.out.println("verifying data from ICM");
	}

	@And("^input payload has the profile update details appended with invalid country code$")
	public void invalidcountryCode() throws FilloException, ParserConfigurationException, SAXException, IOException, TransformerException
	{
		soapXml.selectValueFromExcel("InputValueChange_iBankingRequestPayload_Key","InputValueChange_iBankingRequestPayload_Value","TC_02");
	}

}



