package com.scb.module.collection_cib;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.events.XMLEvent;

public class DemoTest {
  public static void main(String[] args) throws Exception {
	 String keyTag="";
	 String keyTagValue="";
	  String filename = "C:\\Users\\1601017\\Desktop\\RestAPI\\STP Request and Response XML Files\\SCC578PK10A1080519039246_IBanking_eOps_Education_Initial_Req.xml";
		XMLInputFactory inputFactory = XMLInputFactory.newFactory();
		XMLStreamReader reader = inputFactory.createXMLStreamReader(filename, new FileInputStream(filename));
		System.out.println("Hello");
		inputFactory.setProperty(XMLInputFactory.IS_COALESCING, true);
		while (reader.hasNext()) {
			
			switch (reader.next()) {
			
			case XMLStreamConstants.START_ELEMENT:
				
				keyTag = reader.getName().toString();
				System.out.println(keyTag);
				break;
			case XMLStreamConstants.END_ELEMENT:
				break;

			case XMLStreamConstants.CHARACTERS:
				
			case XMLStreamConstants.CDATA:
				System.out.println(reader.getText().toString());
				break;

			}
			
		}
		
	}

}

   