package com.scb.module.collection_cib_Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.assertj.core.api.SoftAssertions;
import com.scb.module.collection_cib.StepDef;


public class CommonFunctions {
	static SoftAssertions softAssertions = new SoftAssertions();
	static StepDef StepDef = new StepDef();
	static CommonUtils coUtil = new CommonUtils();
	static ReadProperties getproperty = new ReadProperties();
	static OrcaleDBConnection dbconnection = new OrcaleDBConnection();
	static XmlUtility xmlUtil = new XmlUtility();
	

	
	public String readProperties(String PropertyFileName,String inputValue) throws FileNotFoundException
	{
		String output="";
		String source=PropertyFileName;
		//File source=new File(System.getProperty("user.dir")+"/src/test/resources/"+PropertyFileName+".properties");
		FileInputStream fis=new FileInputStream(source);
		Properties properties=new Properties();
		try {
			properties.load(fis);
			output=properties.getProperty("inputValue");
			return output;
		} catch (IOException e) {
			
			output="Please enter valid key value";
			return output;
		}
		
		
	}
	

}
